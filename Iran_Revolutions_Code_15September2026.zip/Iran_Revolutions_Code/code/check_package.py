#!/usr/bin/env python3
"""Check the public research package without private texts or model refitting.

This checks file identity, mappings and numerical consistency. It does not verify
the truth of every source claim or regenerate text extraction from absent texts.
Only Python's standard library is required.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import csv
import hashlib
import json
import math
from pathlib import Path
import re
import statistics
import sys


def csv_rows(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def json_file(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def truth(value):
    return str(value).strip().lower() in {"true", "1", "yes"}


def integer(value):
    return int(float(value))


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def close(actual, expected, tolerance=1e-6):
    require(math.isfinite(float(actual)) and abs(float(actual)-float(expected)) <= tolerance,
            f"Expected {expected}, found {actual} (tolerance {tolerance})")


def percentile(values, fraction):
    values = sorted(float(v) for v in values)
    position = (len(values)-1)*fraction
    lower = int(math.floor(position)); upper = int(math.ceil(position))
    return values[lower] + (position-lower)*(values[upper]-values[lower])


def auc(outcomes, scores):
    positive = [s for y,s in zip(outcomes,scores) if y == 1]
    negative = [s for y,s in zip(outcomes,scores) if y == 0]
    require(positive and negative, "Both outcomes are required for AUROC.")
    return sum((p > n) + 0.5*(p == n) for p in positive for n in negative)/(len(positive)*len(negative))


def prediction_metrics(rows, model):
    y = [integer(row["outcome"]) for row in rows]
    p = [float(row[model]) for row in rows]
    require(all(0 <= value <= 1 for value in p), f"Invalid {model} probability")
    positives = sum(y); negatives = len(y)-positives
    sensitivity = sum(outcome == 1 and value >= 0.5 for outcome,value in zip(y,p))/positives
    specificity = sum(outcome == 0 and value < 0.5 for outcome,value in zip(y,p))/negatives
    return {"auroc":auc(y,p), "brier":sum((outcome-value)**2 for outcome,value in zip(y,p))/len(y),
            "balanced_accuracy_at_0_5":(sensitivity+specificity)/2}


class PackageChecker:
    def __init__(self, root):
        self.root = root
        self.checks = []

    def run(self, name, function):
        try:
            detail = function()
            record = {"check":name, "status":"PASS", "detail":str(detail or "Verified")}
        except Exception as exc:
            record = {"check":name, "status":"FAIL", "detail":f"{type(exc).__name__}: {exc}"}
        self.checks.append(record)
        print(f"[{record['status']}] {name}: {record['detail']}")

    def rows(self, relative):
        return csv_rows(self.root/relative)

    def load(self, relative):
        return json_file(self.root/relative)

    def required_files(self):
        paths = [
            "README.md", "requirements.txt", "code/check_package.py", "code/make_figures.py",
            "code/corpus/README.md", "code/corpus/analyze_corpus.py", "code/corpus/reference_mapping.py",
            "code/corpus/extract_sources.py", "code/corpus/recover_additional_sources.py",
            "code/corpus/inputs/source_register.csv", "code/corpus/inputs/dictionaries.json",
            "code/corpus/inputs/pdf_extraction_plan.json", "code/corpus/inputs/additional_source_recipes.json",
            "code/navco/README.md", "code/navco/run_analysis.py", "code/navco/download_data.py",
            "code/navco/analysis_plan.json", "data/navco/source_manifest.json", "data/navco/predictor_dictionary.csv",
            "data/navco/NAVCO2-1_ForPublication.dta", "data/navco/NAVCO_2.1_codebook.pdf",
            "references/reference_crosswalk.csv", "references/references_numbered.txt",
            "references/references_zotero.ris", "references/references_csl.json",
            "outputs/corpus/corpus_run_summary.json", "outputs/corpus/source_manifest.csv",
            "outputs/corpus/source_cluster_coordinates.csv", "outputs/corpus/dictionary_summary.csv",
            "outputs/corpus/dictionary_source_counts.csv", "outputs/corpus/dictionary_term_counts.csv",
            "outputs/corpus/cluster_selection.csv", "outputs/corpus/cluster_seed_stability.csv",
            "outputs/navco/run_summary.json", "outputs/navco/campaign_analysis_data.csv",
            "outputs/navco/primary_performance.csv", "outputs/navco/country_heldout_predictions.csv",
            "outputs/navco/performance_bootstrap.csv", "outputs/navco/nonviolent_refit_performance_intervals.csv",
            "outputs/navco/predictions_nonviolent_onset.csv", "outputs/navco/temporal_performance.csv",
            "outputs/navco/predictions_temporal_only.csv", "outputs/navco/predictions_temporal_and_unseen_country.csv",
        ]
        missing = [path for path in paths if not (self.root/path).is_file() or (self.root/path).stat().st_size == 0]
        require(not missing, "Missing or empty required files: "+", ".join(missing))
        return f"{len(paths)} required files present and nonempty"

    def reference_identities(self):
        crosswalk = self.rows("references/reference_crosswalk.csv")
        register = self.rows("code/corpus/inputs/source_register.csv")
        identifiers = [row["reference_id"] for row in crosswalk]
        registered = [row['reference_id'] for row in register]
        notices = {row['reference_id'] for row in crosswalk if truth(row['is_correction_notice'])}
        require(len(set(identifiers))==len(crosswalk), 'Duplicate bibliography identity')
        require(len(set(registered))==len(register), 'Duplicate registered identity')
        require(set(identifiers)==set(registered)|notices and not set(registered)&notices,'Bibliography identity accounting differs')
        numbers = [integer(row["final_reference_number"]) for row in crosswalk]
        require(numbers==list(range(1,len(crosswalk)+1)), 'Crosswalk must be ordered and contiguous')
        require(sorted(integer(r['source_register_number']) for r in register)==list(range(1,len(register)+1)),'Source register numbering differs')
        summary=self.load('outputs/corpus/corpus_run_summary.json')
        require(summary['registered_sources']==len(register) and summary['bibliography_entries']==len(crosswalk),'Summary source counts differ')
        require(summary['ancillary_correction_notices']==len(notices),'Notice counts differ')
        return f'{len(register)} source identities; {len(crosswalk)} bibliography entries; {len(notices)} notices'

    def corrections(self):
        mapping = {row["reference_id"]:row for row in self.rows("references/reference_crosswalk.csv")}
        expected = {"R183":"R005", "R182":"R034", "R184":"R140"}
        for notice,parent in expected.items():
            row = mapping[notice]
            require(truth(row["is_correction_notice"]), f"{notice} not identified as notice")
            require(row["parent_source_id"]==parent, f"Wrong parent for {notice}")
            require(integer(row["final_reference_number"])==integer(mapping[parent]["final_reference_number"])+1,
                    f"{notice} does not immediately follow {parent}")
            require(not truth(row["include_text_analysis"]), f"Notice {notice} incorrectly enters corpus")
        return "Three correction notices are unique, outside the text corpus, and adjacent to their originals"

    def bibliography_formats(self):
        crosswalk = self.rows("references/reference_crosswalk.csv")
        expected = ["IranStudy-"+row["reference_id"] for row in crosswalk]
        csl = self.load("references/references_csl.json")
        require([row["id"] for row in csl]==expected, "CSL identities/order differ from crosswalk")
        ris = (self.root/"references/references_zotero.ris").read_text(encoding="utf-8")
        require(re.findall(r"^ID  - (.+)$",ris,re.M)==expected, "RIS identities/order differ from crosswalk")
        require(len(re.findall(r"^TY  - ",ris,re.M))==len(crosswalk) and len(re.findall(r"^ER  -",ris,re.M))==len(crosswalk),
                "RIS record boundaries differ from bibliography count")
        numbered = (self.root/"references/references_numbered.txt").read_text(encoding="utf-8")
        bracketed=re.findall(r'^\[(\d+)\] ',numbered,re.M);dotted=re.findall(r'^(\d+)\. ',numbered,re.M)
        require(not (bracketed and dotted),'Numbered reference styles are inconsistent')
        require([int(v) for v in (bracketed or dotted)]==list(range(1,len(crosswalk)+1)), "Numbered references are not contiguous")
        dois = [row["DOI"].strip().lower() for row in csl if row.get("DOI")]
        require(len(dois)==len(set(dois)), "Duplicate DOI requires bibliographic review")
        return f'RIS, CSL JSON and numbered list agree with the {len(crosswalk)}-entry crosswalk; DOI values are unique'

    def source_mapping(self):
        crosswalk = {row["reference_id"]:row for row in self.rows("references/reference_crosswalk.csv")}
        register = {row["reference_id"]:row for row in self.rows("code/corpus/inputs/source_register.csv")}
        files = ["code/corpus/inputs/source_register.csv", "outputs/corpus/source_manifest.csv",
                 "outputs/corpus/source_cluster_coordinates.csv", "outputs/corpus/dictionary_source_counts.csv",
                 "outputs/corpus/dictionary_term_counts.csv", "outputs/corpus/pdf_extraction_log.csv"]
        for filename in files:
            for row in self.rows(filename):
                identity = row["reference_id"]
                require(identity in register, f"Unknown or ancillary identity in {filename}: {identity}")
                original, reference = register[identity], crosswalk[identity]
                for field in ["current_reference_number", "final_reference_number"]:
                    if field in row:
                        require(integer(row[field])==integer(reference["final_reference_number"]), f"Stale {field}: {filename}/{identity}")
                if "source_register_number" in row:
                    require(integer(row["source_register_number"])==integer(original["source_register_number"]), f"Wrong register number: {identity}")
                for field in ["source_role", "event_coverage", "title"]:
                    if field in row:
                        require(row[field]==original[field], f"Metadata mismatch: {filename}/{identity}/{field}")
        for filename in ["code/corpus/inputs/pdf_extraction_plan.json", "code/corpus/inputs/additional_source_recipes.json"]:
            for row in self.load(filename)["sources"]:
                identity=row["reference_id"]
                require(identity in register, f"Unknown recovery identity: {identity}")
                for field in ["current_reference_number", "final_reference_number"]:
                    require(integer(row[field])==integer(crosswalk[identity]["final_reference_number"]), f"Stale recipe mapping: {filename}/{identity}")
        return "Stable source IDs, citation numbers and shared metadata agree across public inputs and outputs"

    def corpus_cardinality(self):
        register=self.rows("code/corpus/inputs/source_register.csv")
        manifest=self.rows("outputs/corpus/source_manifest.csv")
        require(len(manifest)==len(register) and len({r['reference_id'] for r in manifest})==len(register),'Source manifest cardinality differs')
        included=[row for row in manifest if truth(row["eligible_text_analysis"])]
        require({r["reference_id"] for r in included}=={r["reference_id"] for r in register if truth(r["include_text_analysis"])},"Eligibility mismatch")
        require(all(r["language"]=="en" and r["fulltext_status"] in {"complete","selected_complete_contribution"} for r in included),"Incomplete/non-English source marked eligible")
        hashes=[r["normalized_text_sha256"] for r in included]
        require(all(re.fullmatch(r"[0-9a-f]{64}",value) for value in hashes),"Missing or malformed normalized text hash")
        require(len(set(hashes))==len(included),"Duplicate normalized source hash")
        summary=self.load("outputs/corpus/corpus_run_summary.json")
        expected={'registered_sources':len(register),'bibliography_entries':len(self.rows('references/reference_crosswalk.csv')),
                  'eligible_English_sources':len(included),'excluded_from_text_mapping':len(register)-len(included),
                  'eligible_raw_words':sum(integer(r['raw_words']) for r in included),
                  'eligible_normalized_words':sum(integer(r['normalized_words']) for r in included)}
        for key,value in expected.items():
            require(summary[key]==value,f"Run summary mismatch: {key}")
        require(summary['eligible_scope_counts']==dict(Counter(r['fulltext_status'] for r in included)),'Scope counts differ')
        require(summary["public_outputs_contain_source_full_text"] is False,"Unexpected full-text redistribution flag")
        return f'{len(register)} registered / {len(included)} eligible; scopes and word counts consistent'

    def recorded_input_hashes(self):
        summary=self.load("outputs/corpus/corpus_run_summary.json")
        for key,path in {"source_register_sha256":"code/corpus/inputs/source_register.csv","lexicon_sha256":"code/corpus/inputs/dictionaries.json","reference_crosswalk_sha256":"references/reference_crosswalk.csv"}.items():
            require(sha256(self.root/path)==summary[key],f"Recorded input checksum differs: {path}")
        recipes=self.load("code/corpus/inputs/additional_source_recipes.json")
        require(recipes["source_register_sha256"]==summary["source_register_sha256"],"Recipe register hash differs")
        plan=self.load("code/corpus/inputs/pdf_extraction_plan.json")
        require(len(plan["sources"])==117 and len({s["reference_id"] for s in plan["sources"]})==117,"Expected 117 unique PDF recovery identities")
        require(all(integer(s["historical_pdf_id"])!=89 for s in plan["sources"]),"Duplicate historical PDF89 must not be ingested")
        require(len({s['reference_id'] for s in recipes['sources']})==len(recipes['sources']),'Duplicate additional-source recovery recipe')
        for row in self.rows("code/corpus/inputs/source_register.csv"):
            for field in ["local_text_path","local_segments_path","local_binary_path","retrieval_metadata_path","auxiliary_abstract_path"]:
                path=row.get(field,"")
                if path:
                    require(not Path(path).is_absolute() and ".." not in Path(path).parts,f"Nonportable source path: {row['reference_id']}/{field}")
        return "Registered public-input SHA-256 values match; recovery metadata are portable; duplicate PDF89 excluded"

    def corpus_results(self):
        summary=self.load("outputs/corpus/corpus_run_summary.json")
        coordinates=self.rows("outputs/corpus/source_cluster_coordinates.csv")
        n=summary['eligible_English_sources'];dimensions=summary['svd_dimensions']
        require(len(coordinates)==n,"Coordinate count differs")
        observed=Counter(integer(r['cluster']) for r in coordinates)
        require(dict(observed)=={int(k):v for k,v in summary['cluster_sizes'].items()},'Cluster membership sizes differ')
        require(len(observed)==summary['selected_k'],'Selected cluster count differs')
        for row in coordinates:
            require(all(math.isfinite(float(row[f"svd_{i:02d}"])) for i in range(1,dimensions+1)),"Missing/nonfinite SVD coordinate")
        selection=self.rows('outputs/corpus/cluster_selection.csv');selected=[r for r in selection if truth(r['selected'])]
        require(len(selected)==1 and integer(selected[0]['k'])==summary['selected_k'],'Selected k differs')
        close(selected[0]['mean_silhouette'],summary['selected_mean_silhouette'],1e-8)
        require(float(selected[0]['mean_silhouette'])>=max(float(r['mean_silhouette']) for r in selection)-1e-8,'Selected k does not maximize mean silhouette')
        stability=self.rows('outputs/corpus/cluster_seed_stability.csv')
        close(statistics.median(float(r['adjusted_rand_index']) for r in stability),summary['median_pairwise_seed_adjusted_rand'],1e-8)
        dictionaries=self.load("code/corpus/inputs/dictionaries.json")["categories"]
        require({r["category_id"] for r in dictionaries}=={f"D{i:02d}" for i in range(1,15)},"Dictionary IDs differ")
        source_counts=self.rows("outputs/corpus/dictionary_source_counts.csv")
        require(len(source_counts)==n,"Dictionary source count differs")
        require({r['reference_id'] for r in source_counts}=={r['reference_id'] for r in coordinates},'Dictionary and cluster identities differ')
        table=self.rows("outputs/corpus/dictionary_summary.csv")
        require(len(table)==14,"Expected 14 dictionary summaries")
        for row in table:
            category=row["category_id"]
            present=sum(float(r[category])>0 for r in source_counts)
            require(integer(row['n_sources'])==n and integer(row['sources_with_mentions'])==present,f'Presence mismatch: {category}')
            close(row['presence_pct'],100*present/n,1e-6)
        return f'{summary["selected_k"]} clusters, {dimensions} finite coordinates per source, 14 dictionaries and consistent presence counts'

    def navco_source(self):
        manifest=self.load("data/navco/source_manifest.json")
        require(manifest["doi"]=="10.7910/DVN/MHOXDV" and manifest["license"]=="CC0 1.0","Unexpected NAVCO source/license")
        require(manifest["observed_campaigns"]==384 and manifest["observed_campaign_years"]==2717 and manifest["observed_year_range"]==[1945,2013],"Unexpected official-data cardinality metadata")
        for entry in manifest["files"]:
            path=self.root/"data/navco"/entry["filename"]
            require(path.is_file(),f"Missing source-manifest file: {entry['filename']}")
            require(path.stat().st_size==entry["bytes"] and sha256(path)==entry["sha256"],f"Original source checksum differs: {entry['filename']}")
        require(sha256(self.root/"data/navco/NAVCO2-1_ForPublication.dta")=="a2c30863f021e4cf2aa334d65d3a0f03209c40a8d4f0324f4f886f6cdc6deb76","Pinned DTA checksum differs")
        return "Official NAVCO files match their recorded hashes and pinned release; CC0 license recorded"

    def navco_cohort(self):
        rows=self.rows("outputs/navco/campaign_analysis_data.csv")
        require(len(rows)==127 and len({r["campaign_id"] for r in rows})==127,"Primary cohort cardinality differs")
        require(len({r["country_group"] for r in rows})==75,"Expected 75 country groups")
        require(sum(integer(r["outcome"]) for r in rows)==43,"Expected 43 five-year successes")
        require(sum(integer(r["prim_meth"])==1 for r in rows)==47,"Expected 47 nonviolent-onset campaigns")
        require(sum(integer(r["ongoing_at_2013"]) for r in rows)==13,"Expected 13 ongoing campaigns")
        require(sum(integer(r["goal_changed"]) for r in rows)==10,"Expected 10 goal changes")
        require(all(integer(r["onset_year"])<=2008 and integer(r["final_observed_year"])>integer(r["onset_year"]) for r in rows),"Invalid five-year eligibility")
        flow=self.rows("outputs/navco/cohort_flow.csv")
        require([integer(r["n"]) for r in flow]==[384,225,183,143,127],"Cohort flow differs")
        return "127 campaigns, 75 country groups, 43 successes; onset/follow-up selection and flow verified"

    def navco_predictions(self, nonviolent=False):
        suffix="predictions_nonviolent_onset.csv" if nonviolent else "country_heldout_predictions.csv"
        results_file="nonviolent_refit_performance_intervals.csv" if nonviolent else "primary_performance.csv"
        rows=self.rows("outputs/navco/"+suffix)
        expected_n,expected_countries,expected_events=(47,39,29) if nonviolent else (127,75,43)
        require(len(rows)==expected_n and len({r["campaign_id"] for r in rows})==expected_n,"Prediction cardinality differs")
        require(len({r["country_group"] for r in rows})==expected_countries and sum(integer(r["outcome"]) for r in rows)==expected_events,"Prediction groups/outcomes differ")
        groups=defaultdict(set)
        for row in rows:groups[row["country_group"]].add(integer(row["fold"]))
        require(all(len(value)==1 for value in groups.values()),"A country appears in multiple held-out folds")
        require({integer(r["fold"]) for r in rows}=={1,2,3,4,5},"Expected five held-out folds")
        cohort={r["campaign_id"]:r for r in self.rows("outputs/navco/campaign_analysis_data.csv")}
        for row in rows:
            require(row["campaign_id"] in cohort,"Unknown predicted campaign")
            original=cohort[row["campaign_id"]]
            require(integer(row["outcome"])==integer(original["outcome"]) and row["country_group"]==original["country_group"],"Prediction metadata mismatch")
            if nonviolent:require(integer(original["prim_meth"])==1,"Violent onset in nonviolent-only refit")
        performance={(r["model"],r["metric"]):r for r in self.rows("outputs/navco/"+results_file)}
        expected={"logistic":(0.498084,0.274300),"random_forest":(0.451149,0.238419)} if nonviolent else {"logistic":(0.632337,0.233563),"random_forest":(0.742386,0.194131)}
        for model in ["prevalence","logistic","random_forest"]:
            computed=prediction_metrics(rows,model)
            for metric,value in computed.items():close(performance[(model,metric)]["estimate"],value,1e-12)
            if model in expected:
                close(computed["auroc"],expected[model][0]);close(computed["brier"],expected[model][1])
        return f"{expected_n} held-out predictions reproduce AUROC, Brier and balanced accuracy; country folds do not overlap"

    def bootstrap_intervals(self):
        draws=self.rows("outputs/navco/performance_bootstrap.csv")
        require(len(draws)==6000,"Expected 2,000 bootstrap draws for each of three models")
        groups=defaultdict(list)
        for row in draws:groups[row["model"]].append(row)
        results=self.rows("outputs/navco/primary_performance.csv")
        for model,rows in groups.items():
            require(len(rows)==2000 and len({r["draw"] for r in rows})==2000,f"Bootstrap count differs: {model}")
        for row in results:
            if row["lower_95"]:
                values=[float(r[row["metric"]]) for r in groups[row["model"]]]
                close(row["lower_95"],percentile(values,.025),1e-10)
                close(row["upper_95"],percentile(values,.975),1e-10)
        return "Primary reported 95% intervals match the supplied 2,000 country-bootstrap draws per model"

    def temporal_check(self):
        cohort=self.rows("outputs/navco/campaign_analysis_data.csv")
        later=[r for r in cohort if integer(r["onset_year"])>=1990]
        earlier=[r for r in cohort if integer(r["onset_year"])+5<1990]
        later_countries={r["country_group"] for r in later}
        strict=[r for r in earlier if r["country_group"] not in later_countries]
        require((len(earlier),sum(integer(r["outcome"]) for r in earlier),len(later),sum(integer(r["outcome"]) for r in later),len(strict))==(58,11,52,25,47),"Temporal cohort counts or purge differ")
        metrics={(r["analysis"],r["model"]):r for r in self.rows("outputs/navco/temporal_performance.csv")}
        for name,training in [("temporal_only",earlier),("temporal_and_unseen_country",strict)]:
            rows=self.rows(f"outputs/navco/predictions_{name}.csv")
            require({r["campaign_id"] for r in rows}=={r["campaign_id"] for r in later},"Later-period predicted campaigns differ")
            for model in ["prevalence","logistic","random_forest"]:
                reported=metrics[(name,model)]
                require(integer(reported["training_n"])==len(training) and integer(reported["test_n"])==52,"Temporal sample count differs")
                for measure,value in prediction_metrics(rows,model).items():close(reported[measure],value,1e-12)
                if name.endswith("unseen_country"):require(integer(reported["country_overlap"])==0,"Strict temporal-country overlap")
        return "Training labels end before 1990; 58/52 temporal split and 47/52 unseen-country split reproduce reported metrics"

    def figures(self):
        names=["Graphical_Abstract"]+[f"Figure_{i}" for i in range(1,8)]+[f"Figure_S{i}" for i in range(1,4)]
        for name in names:
            for extension in ["png","pdf","svg"]:
                path=self.root/"figures"/f"{name}.{extension}"
                require(path.is_file() and path.stat().st_size>1000,f"Missing/empty figure: {path.name}")
                prefix=path.read_bytes()[:4096]
                signature={"png":prefix.startswith(b"\x89PNG\r\n\x1a\n"),"pdf":prefix.startswith(b"%PDF-"),"svg":b"<svg" in prefix}[extension]
                require(signature,f"Unexpected figure format: {path.name}")
        return "Graphical abstract, seven main figures and three supplementary figures exist in PNG/PDF/SVG formats"

    def public_release(self):
        forbidden_names={"private","original_pdfs","source_texts","retrieval","ocr_work","prior_package_extracted","__pycache__",".venv"}
        offending=[str(p.relative_to(self.root)) for p in self.root.rglob("*") if p.is_dir() and p.name in forbidden_names]
        source_texts=[str(p.relative_to(self.root)) for p in self.root.rglob("*.txt") if re.fullmatch(r"R\d{3}(?:\..+)?\.txt",p.name)]
        cached=[str(p.relative_to(self.root)) for p in self.root.rglob("*.pyc")]
        require(not offending and not source_texts and not cached,"Private recovery/cache items found: "+", ".join(offending+source_texts+cached))
        require((self.root/".gitignore").is_file(),"Public package should include its .gitignore")
        return "No recognized private recovery folders, source-text files or Python caches; .gitignore present"

    def source_audit_records(self):
        folder=self.root/"references/audit"
        names=["mechanism_source_locators.csv","mechanism_case_framework.csv","reference_doi_metadata_audit.csv",
               "suggested_reference_patches.json","proposed_correction_notices_csl.json",
               "source_search_log.json","september_source_ledger.json","comparative_source_ledger.json",
               "september_and_democracy_sources.json","source_extension_id_map.json"]
        require(all((folder/name).is_file() and (folder/name).stat().st_size>0 for name in names),"Source audit records missing or empty")
        registered={r["reference_id"] for r in self.rows("code/corpus/inputs/source_register.csv")}
        audit=csv_rows(folder/"reference_doi_metadata_audit.csv")
        require(len(audit)==len(registered) and {r["source_id"] for r in audit}==registered,"Reference DOI audit does not account for all registered identities")
        for name in ["mechanism_source_locators.csv","mechanism_case_framework.csv"]:
            for row in csv_rows(folder/name):
                values=row.get("source_id",row.get("source_ids",""))
                ids=set(re.findall(r"R\d{3}",values))
                require(ids and ids<=registered,f"Unmapped source identity in {name}")
        notices=json_file(folder/"proposed_correction_notices_csl.json")
        require({row["id"] for row in notices}=={"IranStudy-R182","IranStudy-R183","IranStudy-R184"},"Audit correction-notice identities differ")
        patches=json_file(folder/"suggested_reference_patches.json")
        require(set(patches["existing_source_patches"])<=registered,"Reference-patch identity missing from register")
        return f'{len(names)} source-audit records present; {len(registered)} metadata-audit identities and all mechanism/notice links resolve'


def public_hashes(root, excluded):
    files=[]
    for name in ["README.md","requirements.txt",".gitignore","CITATION.cff"]:
        path=root/name
        if path.is_file():files.append(path)
    for folder in ["code","data","outputs","references","figures"]:
        directory=root/folder
        if directory.exists():
            files.extend(path for path in directory.rglob("*") if path.is_file() and "__pycache__" not in path.parts and path.suffix!=".pyc")
    return {path.relative_to(root).as_posix():sha256(path) for path in sorted(set(files)) if path.resolve() not in excluded}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root",type=Path,default=Path(__file__).resolve().parents[1])
    parser.add_argument("--report",type=Path,help="Optional JSON check report; relative to the current working directory")
    parser.add_argument("--manifest",type=Path,help="Optional SHA-256 file inventory; relative to the current working directory")
    parser.add_argument("--public-package",action="store_true",help="Also reject private recovery folders in a release package")
    args=parser.parse_args();root=args.root.resolve()
    checker=PackageChecker(root)
    checks=[("Required public files",checker.required_files),("Source and bibliography identities",checker.reference_identities),
            ("Correction notices",checker.corrections),("Bibliography formats",checker.bibliography_formats),
            ("Source metadata and citation mapping",checker.source_mapping),("Corpus cardinalities",checker.corpus_cardinality),
            ("Recorded public-input checksums",checker.recorded_input_hashes),("Corpus numerical outputs",checker.corpus_results),
            ("Official NAVCO source files",checker.navco_source),("NAVCO primary cohort",checker.navco_cohort),
            ("NAVCO primary predictions",checker.navco_predictions),
            ("NAVCO nonviolent-only refit",lambda:checker.navco_predictions(nonviolent=True)),
            ("NAVCO bootstrap intervals",checker.bootstrap_intervals),("NAVCO temporal validation",checker.temporal_check),
            ("Publication figure files",checker.figures)]
    if args.public_package:
        checks.extend([("Source audit records",checker.source_audit_records),("Public-release source exclusion",checker.public_release)])
    for name,function in checks:checker.run(name,function)
    excluded={p.resolve() for p in [args.report,args.manifest] if p is not None}
    inventory=public_hashes(root,excluded)
    failed=sum(c["status"]=="FAIL" for c in checker.checks)
    result={"status":"FAIL" if failed else "PASS","checks":checker.checks,"public_file_count":len(inventory),
            "public_sha256":inventory,
            "scope":"Offline public-file and numerical-consistency checks; no private-text hash verification, source factual adjudication, model refitting or automatic proof of scientific validity."}
    if args.report:
        args.report.parent.mkdir(parents=True,exist_ok=True)
        args.report.write_text(json.dumps(result,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
    if args.manifest:
        args.manifest.parent.mkdir(parents=True,exist_ok=True)
        args.manifest.write_text("".join(f"{digest}  {path}\n" for path,digest in inventory.items()),encoding="utf-8")
    print(f"\n{result['status']}: {len(checker.checks)-failed}/{len(checker.checks)} checks passed; SHA-256 inventory covers {len(inventory)} public files.")
    print("Private source texts were not accessed or required.")
    return 1 if failed else 0


if __name__=="__main__":
    sys.exit(main())
