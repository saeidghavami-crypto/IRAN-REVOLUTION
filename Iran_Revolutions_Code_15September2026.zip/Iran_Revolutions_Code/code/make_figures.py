"""Render publication figures from saved analytical results.

Decorative depth is used for conceptual panels only. Statistical values use
undistorted axes. Figure 2 uses three actual SVD coordinates, not invented scores.
"""
from pathlib import Path
import json, textwrap, hashlib, argparse
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Polygon, Circle, FancyArrowPatch, Ellipse

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'figures'; OUT.mkdir(exist_ok=True)
C=ROOT/'outputs/corpus'; N=ROOT/'outputs/navco'
NAVY='#17324D'; TEAL='#237D88'; CORAL='#AC5144'; GOLD='#BA8A3A'; PURPLE='#6B6192'
INK='#22384A'; MUTED='#53697A'; PALE='#EDF3F6'; EDGE='#BBCBD5'
ENDPOINT='15 September 2026'
PALETTE=[TEAL,GOLD,CORAL,PURPLE,NAVY,'#668A62','#6B96AD','#9E7459','#697672','#C18C99']
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':13,'axes.titlesize':15,
                     'axes.labelsize':13,'xtick.labelsize':11,'ytick.labelsize':11,
                     'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none',
                     'pdf.fonttype':42,'savefig.facecolor':'white'})

def base(title,size=(12,5.4)):
    fig=plt.figure(figsize=size,facecolor='white')
    ax=fig.add_axes([0,0,1,1]);ax.set_xlim(0,12);ax.set_ylim(0,size[1]);ax.axis('off')
    ax.text(.25,size[1]-.2,title,color=NAVY,fontsize=19,fontweight='bold',va='top')
    ax.plot([.25,11.75],[size[1]-.66]*2,color=EDGE,lw=1)
    return fig,ax

def card(ax,x,y,w,h,title,body='',color=TEAL,fs=13,titlefs=15,wrap=36):
    dx=.09;dy=-.09
    ax.add_patch(Polygon([[x,y],[x+w,y],[x+w+dx,y+dy],[x+dx,y+dy]],fc='#B5C5D0',ec='none',zorder=1))
    ax.add_patch(Polygon([[x+w,y],[x+w,y+h],[x+w+dx,y+h+dy],[x+w+dx,y+dy]],fc='#CAD6DE',ec='none',zorder=1))
    rect=FancyBboxPatch((x,y),w,h,boxstyle='round,pad=.035,rounding_size=.11',fc='white',ec=EDGE,lw=1.2,zorder=2)
    ax.add_patch(rect)
    ax.add_patch(FancyBboxPatch((x,y+h-.44),w,.44,boxstyle='round,pad=.035,rounding_size=.10',fc=color,ec='none',zorder=3))
    ax.text(x+.14,y+h-.22,title,fontsize=titlefs,color='white',va='center',weight='bold',zorder=5)
    if body:
        text='\n'.join(textwrap.fill(part,wrap,break_long_words=False,break_on_hyphens=False) for part in body.split('\n'))
        ax.text(x+.15,y+h-.61,text,color=INK,fontsize=fs,va='top',linespacing=1.28,zorder=5)

def arrow(ax,x1,y1,x2,y2,color=MUTED,lw=2):
    ax.add_patch(FancyArrowPatch((x1,y1),(x2,y2),arrowstyle='-|>',mutation_scale=15,lw=lw,color=color,zorder=7))

def ribbon(ax,text,y=.1,color=NAVY):
    ax.add_patch(FancyBboxPatch((.25,y),11.5,.5,boxstyle='round,pad=.02,rounding_size=.1',fc=color,ec='none'))
    ax.text(6,y+.25,text,ha='center',va='center',color='white',fontsize=13,weight='bold')

def save(fig,name):
    for ext in ['png','pdf','svg']:
        fig.savefig(OUT/f'{name}.{ext}',dpi=400,bbox_inches='tight',pad_inches=.035)
    plt.close(fig)

def corpus_summary():
    return json.loads((C/'corpus_run_summary.json').read_text())

def navco_summary():
    return json.loads((N/'run_summary.json').read_text())

def globe(ax,x,y,r=.39):
    """Schematic globe: conceptual decoration, not a geographic data map."""
    ax.add_patch(Ellipse((x+.08,y-r-.07),2.05*r,.23*r,color='#D9E2E8',zorder=1))
    for radius,col in [(r,NAVY),(.94*r,TEAL),(.82*r,'#3A929B')]:
        ax.add_patch(Circle((x-.035*(r-radius)/r,y+.025*(r-radius)/r),radius,fc=col,ec='none',zorder=2))
    for width in [.62,1.35]:
        ax.add_patch(Ellipse((x,y),width*r,1.87*r,fill=False,edgecolor='#BDDADD',lw=.8,zorder=3))
    for off,width in [(-.38,1.73),(0,1.88),(.38,1.73)]:
        ax.add_patch(Ellipse((x,y+off*r),width*r,.32*r,fill=False,edgecolor='#BDDADD',lw=.8,zorder=3))
    ax.add_patch(Circle((x-.25*r,y+.28*r),.29*r,fc='white',ec='none',alpha=.12,zorder=4))

def papers(ax,x,y,scale=.62):
    """Layered source pages; depth has no quantitative meaning."""
    for i,col in [(2,'#C3D0D9'),(1,'#DFE8ED'),(0,'white')]:
        dx=i*.10*scale;dy=-i*.09*scale
        ax.add_patch(FancyBboxPatch((x+dx,y+dy),.86*scale,1.05*scale,
                     boxstyle='round,pad=.018,rounding_size=.03',fc=col,ec=EDGE,lw=.8,zorder=3-i))
    ax.add_patch(Polygon([[x+.61*scale,y+1.05*scale],[x+.86*scale,y+.80*scale],
                          [x+.61*scale,y+.80*scale]],fc=PALE,ec=EDGE,lw=.5,zorder=4))
    for j,width in enumerate([.48,.55,.55,.40]):
        ax.plot([x+.13*scale,x+(.13+width)*scale],[y+(.70-.15*j)*scale]*2,
                color=TEAL if j==0 else EDGE,lw=2 if j==0 else 1.3,zorder=4)

def graphical_abstract():
    s=corpus_summary();n=navco_summary();g=s["eligible_case_coverage"]
    pr=pd.read_csv(N/"primary_performance.csv");nv=pd.read_csv(N/"nonviolent_refit_performance_intervals.csv")
    overall=pr[(pr.model=="random_forest")&(pr.metric=="auroc")].estimate.iloc[0]
    nonviolent=nv[(nv.model=="random_forest")&(nv.metric=="auroc")].estimate.iloc[0]
    fig,ax=base("Revolutions, institutional change and democratic futures",(12,7.05))
    papers(ax,.67,5.46,.63);globe(ax,10.95,5.87,.39)
    ax.text(6,5.98,"An evidence-based comparison of two Iranian revolutions",ha="center",fontsize=14.5,color=INK,weight="bold")
    ax.text(6,5.62,f"Woman, Life, Freedom  |  Lion-and-Sun Revolution  |  Endpoint: {ENDPOINT}",ha="center",fontsize=11.6,color=MUTED)
    card(ax,.3,3.05,3.48,2.25,"DOCUMENTARY EVIDENCE",
         f"{s['registered_sources']} registered sources\n{s['eligible_English_sources']} English text units\n"
         f"{g['WLF']} WLF; {g['LionSun_2025_2026']} Lion-and-Sun;\n{g['comparative_context']} comparative/context\n"
         "Source mapping and chronology",TEAL,13.5,14.5,31)
    card(ax,4.23,3.05,3.48,2.25,"HISTORICAL COMPARISON",
         "Collective action and organization\nCoercion and institutional continuity\nWar and leadership succession\nNo verified transfer of state power by the endpoint",CORAL,13.2,14.3,33)
    card(ax,8.16,3.05,3.48,2.25,"COMPARATIVE ML",
         f"NAVCO 2.1: {n['primary_n']} campaigns\n{n['primary_successes']} five-year successes\n"
         f"Country-held-out forest AUROC\nAll eligible: {overall:.3f}\nNonviolent refit: {nonviolent:.3f}",PURPLE,13.4,14.5,31)
    arrow(ax,3.82,4.12,4.15,4.12);arrow(ax,7.75,4.12,8.08,4.12)
    ax.text(6,2.70,"Three connected goals; distinct evidence and outcomes",ha="center",fontsize=14,color=NAVY,weight="bold")
    card(ax,.3,.90,3.48,1.52,"1  WHY NON-TRANSITION?","Assess documented mechanisms that may explain each observed outcome.",TEAL,13.3,13.2,31)
    card(ax,4.23,.90,3.48,1.52,"2  FUTURE CONDITIONS","Identify and test observable conditions linked to future institutional change.",CORAL,13.3,13.2,31)
    card(ax,8.16,.90,3.48,1.52,"3  GLOBAL DEMOCRACY","Connect popular mobilization to transfer, democratic quality and durability.",PURPLE,13.3,13.2,31)
    ribbon(ax,"Mobilization, transfer of power and durable democracy are separate outcomes.",.10)
    save(fig,"Graphical_Abstract")

def figure1():
    fig,ax=base("Chronology of public challenge and institutional response",(12,8.35))
    items=[
      ("September 2022","Amini’s detention and death; Woman, Life, Freedom spreads",TEAL),
      ("2022–2025","Continued public resistance, civic and labour action, and published transition charters",TEAL),
      ("28 December 2025","Economic protest and bazaar closures begin the later revolution",CORAL),
      ("6–9 January 2026","Pahlavi’s call for 8–9 January action precedes mass killings and a communications blackout",CORAL),
      ("2–14 February 2026","Pahlavi’s Global Day call precedes international demonstrations on 14 February",PURPLE),
      ("28 February 2026","Armed conflict changes the context; wartime events are analysed as a distinct phase",GOLD),
      ("March 2026","Assembly of Experts appoints Mojtaba Khamenei: succession within existing state institutions",NAVY),
      ("July–September 2026","Continued detention, protest-related executions and judicial or security enforcement",CORAL),
      ("15 September 2026","Observation endpoint: no verified transfer of state power; future outcomes remain open",PURPLE)]
    xs=[.3,4.23,8.16]
    for i,(title,body,color) in enumerate(items):
        row=i//3;col=i%3
        card(ax,xs[col],[5.48,3.28,1.08][row],3.48,1.72,title,body,color,13.1,14.1,33)
    for y in [6.30,4.10,1.90]:
        arrow(ax,3.82,y,4.15,y);arrow(ax,7.75,y,8.08,y)
    for y,label in [(7.43,"PHASE 1  |  PUBLIC CHALLENGE AND CONTINUED RESISTANCE"),(5.23,"PHASE 2  |  JANUARY REPRESSION, GLOBAL ASSEMBLIES AND WAR ONSET"),(3.03,"PHASE 3  |  SUCCESSION, CONTINUING ENFORCEMENT AND OBSERVATION ENDPOINT")]:
        ax.text(.3,y,label,color=MUTED,fontsize=11.5,weight="bold",va="center")
    ribbon(ax,"Event dates and institutional outcomes are distinguished from retrospective reporting dates.",.15)
    save(fig,"Figure_1")

def figure2():
    s=corpus_summary();d=pd.read_csv(C/"source_cluster_coordinates.csv")
    fig=plt.figure(figsize=(12,6),facecolor="white")
    fig.text(.025,.96,"Documentary coverage and three-dimensional text map",fontsize=19,color=NAVY,weight="bold",va="top")
    ax=fig.add_axes([.025,.17,.3,.68]);ax.set_xlim(0,3.6);ax.set_ylim(0,4.6);ax.axis("off")
    card(ax,.06,3.39,3.25,1.1,f"{s['registered_sources']} source identities",f"{s['bibliography_entries']} reference entries, including {s['ancillary_correction_notices']} correction notices",NAVY,11.8,14,32)
    scopes=s["eligible_scope_counts"]
    card(ax,.06,1.86,3.25,1.13,f"{s['eligible_English_sources']} English text units",f"{scopes.get('complete',0)} whole texts\n{scopes.get('selected_complete_contribution',0)} bounded contributions",TEAL,12.5,14,30)
    arrow(ax,1.7,3.35,1.7,3.1)
    card(ax,.06,.12,3.25,1.34,f"{s['excluded_from_text_mapping']} outside text mapping","Availability, language and\nanalytical-scope exclusions;\nsee source register.",PURPLE,11.9,13.1,31)
    ax=fig.add_axes([.345,.10,.58,.76],projection="3d")
    for k,color in zip(sorted(d.cluster.unique()),PALETTE):
        x=d[d.cluster==k];ax.scatter(x.svd_01,x.svd_02,x.svd_03,s=26,c=color,alpha=.83,edgecolors="white",linewidth=.3,label=f"Cluster {k} (n = {len(x)})")
    ax.set_xlabel("SVD 1",labelpad=8);ax.set_ylabel("SVD 2",labelpad=8);ax.set_zlabel("")
    ax.text2D(.92,.82,"SVD 3",transform=ax.transAxes,rotation=0,fontsize=12,color=INK,ha="right")
    ax.view_init(elev=23,azim=-53)
    for axis in [ax.xaxis,ax.yaxis,ax.zaxis]:axis.pane.set_facecolor("#F4F7F9")
    ax.legend(loc="upper left",bbox_to_anchor=(.02,1.03),frameon=False,fontsize=11,ncol=1)
    fig.text(.34,.87,f"{s['selected_k']} clusters | anchor silhouette {s['anchor_seed_silhouette']:.3f} | median seed ARI {s['median_pairwise_seed_adjusted_rand']:.3f}",fontsize=11.2,color=INK)
    fig.text(.50,.075,f"Displayed axes explain {100*s['svd_first3_explained_variance_ratio']:.2f}% of variance; clustering used all {s['svd_dimensions']} SVD dimensions.",ha="center",fontsize=11,color=MUTED)
    fig.text(.50,.025,"Depth encodes actual text coordinates. Cluster IDs do not denote validated political mechanisms.",ha="center",fontsize=11.5,color=NAVY)
    save(fig,"Figure_2")

LABELS={
 'D01':'Bodily control / gender','D02':'Youth / generations','D03':'Ethnicity / peripheral regions',
 'D04':'Authority / legitimacy','D05':'Economic conditions','D06':'Digital mobilization',
 'D07':'Art / culture / memory','D08':'Repression / security forces','D09':'Digital control / information',
 'D10':'Organization / leadership','D11':'Labour / noncooperation','D12':'Elite / security loyalty',
 'D13':'International solidarity','D14':'Transition arrangements'}

def figure3():
    d=pd.read_csv(C/'dictionary_summary.csv').sort_values('presence_pct')
    fig=plt.figure(figsize=(12,6.3),facecolor='white')
    fig.text(.025,.965,'What the source collection discusses',fontsize=19,color=NAVY,weight='bold',va='top')
    ax=fig.add_axes([.285,.14,.365,.72]);y=np.arange(len(d))
    ax.barh(y,d.presence_pct,color=[TEAL if v!='D12' else GOLD for v in d.category_id],height=.64)
    ax.set_yticks(y,[LABELS[v] for v in d.category_id],fontsize=12)
    ax.set_xlim(0,100);ax.set_xlabel('Sources with at least one dictionary phrase (%)')
    ax.grid(axis='x',alpha=.16);ax.set_axisbelow(True)
    for j,(_,r) in enumerate(d.iterrows()):ax.text(102,j,f'{int(r.sources_with_mentions)}/{int(r.n_sources)}',va='center',fontsize=10.7,color=INK,clip_on=False)
    ax2=fig.add_axes([.75,.16,.23,.7]);ax2.axis('off');ax2.set_xlim(0,3);ax2.set_ylim(0,4.5)
    card(ax2,.08,2.65,2.72,1.52,'Equal source weight','One complete source contributes once to each category.',TEAL,12.5,13,24)
    card(ax2,.08,.55,2.72,1.65,'Interpretation','Mentions describe coverage. They do not measure mechanism strength or causal importance.',PURPLE,12.5,13,24)
    fig.text(.50,.04,'Fourteen phrase dictionaries; exact terms and sensitivity analyses are supplied with the code.',ha='center',fontsize=11.5,color=MUTED)
    save(fig,'Figure_3')

def figure4():
    fig,ax=base("Observed collective action and constraints on institutional transition",(12,5.8))
    card(ax,.30,1.13,3.48,3.67,"WOMAN, LIFE, FREEDOM",
         "Observed action\nWomen’s public resistance; university boycott announcements; sustained local action; labour and civic networks.\n\nInstitutional initiatives\nMinimum-demands and Mahsa charters.\n\nContinuing state enforcement and constraints on coordinated action.",TEAL,12.7,14,33)
    card(ax,4.23,1.13,3.48,3.67,"INSTITUTIONAL CONTINUITY",
         "Domestic constraints\nLethal force, detention, communication disruption and barriers to sustained noncooperation.\n\nAfter 28 February\nWar and leadership succession changed the context. These events did not establish transfer of state power to the revolution.",NAVY,12.7,13.6,33)
    card(ax,8.16,1.13,3.48,3.67,"LION-AND-SUN REVOLUTION",
         "Observed action\nBazaar closures; broad protest; timed calls; international assemblies.\n\nJanuary response\nMass killings and blackout.\n\nJuly–September response\nDetention, protest-related executions and continuing judicial or security enforcement.",CORAL,12.7,13.8,33)
    arrow(ax,3.84,2.95,4.15,2.95);arrow(ax,8.08,2.95,7.75,2.95)
    ribbon(ax,"These observations inform interpretation; they do not establish necessary or sufficient conditions.",.20)
    save(fig,"Figure_4")

def figure5():
    fig,ax=base('International demonstrations on 14 February 2026',(12,6.05))
    card(ax,.3,2.55,3.48,2.43,'MUNICH',
         '≈250,000 at peak\nMunich police\nTheresienwiese',TEAL,16,16,28)
    card(ax,4.23,2.55,3.48,2.43,'TORONTO',
         '≈350,000 reported\nToronto police\nPeak / cumulative scope unspecified',TEAL,15,16,29)
    card(ax,8.16,2.55,3.48,2.43,'LOS ANGELES',
         'Thousands in local reports\n350,000 separately attributed to police by Iran International; direct police figure unverified',CORAL,13.4,16,32)
    card(ax,.3,.93,3.48,1.24,'VANCOUVER','≈50,000; police estimate reported retrospectively',PURPLE,13,14,31)
    card(ax,4.23,.93,3.48,1.24,'MELBOURNE','Up to 4,000; Victoria Police estimate reported by ABC',PURPLE,13,14,31)
    card(ax,8.16,.93,3.48,1.24,'ADDITIONAL CITIES','Sydney, Perth, Adelaide, Brisbane and Hobart',PURPLE,13,14,31)
    ribbon(ax,'Pahlavi’s 2 February call named the three principal cities. Estimates are not summed.',.09)
    save(fig,'Figure_5')

def figure6():
    roc=pd.read_csv(N/'roc_plot_data.csv');pr=pd.read_csv(N/'primary_performance.csv')
    nv=pd.read_csv(N/'nonviolent_refit_performance_intervals.csv')
    ns=navco_summary()
    fig=plt.figure(figsize=(12,5.8),facecolor='white')
    fig.text(.025,.965,'Comparative prediction and its limits in nonviolent campaigns',fontsize=18.5,color=NAVY,weight='bold',va='top')
    ax=fig.add_axes([.07,.22,.37,.61])
    colors={'logistic':TEAL,'random_forest':CORAL};names={'logistic':'Ridge logistic','random_forest':'Shallow forest'}
    for model in colors:
        q=roc[roc.model==model];auc=pr[(pr.model==model)&(pr.metric=='auroc')].iloc[0]['estimate']
        ax.plot(q.false_positive_rate,q.true_positive_rate,lw=2.5,color=colors[model],label=f'{names[model]}  {auc:.3f}')
    ax.plot([0,1],[0,1],ls='--',color='#AAB8C2',lw=1)
    ax.set(xlim=(0,1),ylim=(0,1),xlabel='False-positive rate',ylabel='True-positive rate')
    ax.set_title(f"A  Country-held-out predictions\n{ns['primary_n']} campaigns; {ns['primary_successes']} five-year successes",loc='left',fontsize=13.2,pad=10)
    ax.legend(loc='lower right',frameon=False,fontsize=11);ax.grid(alpha=.14)
    ax2=fig.add_axes([.62,.22,.33,.61])
    y=[3,2,1,0]; rows=[]
    for frame,tag in [(pr,'All eligible'),(nv,'Nonviolent only')]:
        for model in ['logistic','random_forest']:
            r=frame[(frame.model==model)&(frame.metric=='auroc')].iloc[0]
            rows.append((r,model,tag))
    for j,(r,model,tag) in zip(y,rows):
        ax2.errorbar(r.estimate,j,xerr=[[r.estimate-r.lower_95],[r.upper_95-r.estimate]],fmt='o',color=colors[model],capsize=4,lw=2,ms=7)
        ax2.text(.98,j,f'{r.estimate:.3f}',ha='right',va='center',fontsize=12)
    ax2.set_yticks(y,['All / ridge','All / forest','Nonviolent / ridge','Nonviolent / forest'],fontsize=11)
    ax2.set_xlim(.20,1.0);ax2.set_ylim(-.65,3.65);ax2.axvline(.5,color='#AAB8C2',ls='--')
    ax2.set_xlabel('AUROC with country-bootstrap 95% interval')
    ax2.set_title(f"B  Pooled analysis and nonviolent refits\nNonviolent subset: {ns['primary_nonviolent_onset']} campaigns",loc='left',fontsize=12.5,pad=10)
    ax2.grid(axis='x',alpha=.14)
    fig.text(.5,.105,'Useful discrimination was not demonstrated in the small nonviolent-only refits.',ha='center',fontsize=12.8,color=NAVY,weight='bold')
    fig.text(.5,.05,'Model rankings are not calibrated forecasts for either Iranian revolution.',ha='center',fontsize=12,color=MUTED)
    save(fig,'Figure_6')

def figure7():
    fig,ax=base("From non-transition to testable prospects and democratic futures",(12,7.05))
    card(ax,.3,3.68,3.48,2.32,"DOCUMENT WHAT EXISTS","Collective action and organization\nState responses and institutional behaviour\nPublished transition commitments",TEAL,13.3,14.3,31)
    card(ax,4.23,3.68,3.48,2.32,"ASSESS MECHANISMS","Continuity and cross-sector reach\nChanges in institutional support\nCredibility and implementation of commitments",NAVY,13.3,14.3,31)
    card(ax,8.16,3.68,3.48,2.32,"EVALUATE ACROSS CASES","Defined outcome and horizon\nPredictors recorded beforehand\nCountry and temporal validation\nCalibration and subgroup checks",PURPLE,13.1,14.3,31)
    arrow(ax,3.83,4.84,4.15,4.84);arrow(ax,7.76,4.84,8.08,4.84)
    ax.text(6,3.24,"For international comparison, assess three outcomes separately",ha="center",color=NAVY,fontsize=14,weight="bold")
    card(ax,.3,1.05,3.48,1.88,"POPULAR MOBILIZATION","Participation, organization and sustained collective action. Visibility alone does not establish institutional leverage.",TEAL,13.1,14,33)
    card(ax,4.23,1.05,3.48,1.88,"TRANSFER OF STATE POWER","Documented change in institutional authority, with an explicit endpoint and a defined criterion of success.",CORAL,13.1,13.4,33)
    card(ax,8.16,1.05,3.48,1.88,"DEMOCRATIC DURABILITY","Rights, equal citizenship, accountability and the survival and quality of representative institutions.",PURPLE,13.1,13.6,33)
    ribbon(ax,"Democratic quality and durability require evidence beyond a transfer of state power.",.15)
    save(fig,"Figure_7")

def supplement_figures():
    d=pd.read_csv(C/'cluster_selection.csv')
    cs=corpus_summary();k=cs['selected_k'];seeds=cs['selection_seeds']
    fig,ax=plt.subplots(figsize=(10,4.8))
    ax.errorbar(d.k,d.mean_silhouette,yerr=[d.mean_silhouette-d.minimum_silhouette,d.maximum_silhouette-d.mean_silhouette],marker='o',color=TEAL,capsize=4)
    ax.scatter([k],[d[d.k==k].mean_silhouette.iloc[0]],s=110,color=CORAL,zorder=5,label=f'Selected k = {k}')
    ax.set(xlabel='Number of clusters',ylabel=f'Mean silhouette across {len(seeds)} seeds',title=f"Cluster selection uses all {cs['svd_dimensions']} SVD dimensions")
    ax.set_xticks(d.k);ax.legend(frameon=False)
    ax.grid(alpha=.15);fig.tight_layout();save(fig,'Figure_S1')
    d=pd.read_csv(C/'dictionary_strata.csv');q=d[d.dimension=='event_coverage']
    cats=list(LABELS);preferred=['WLF','LionSun_2025_2026','comparative_context']
    groups=[g for g in preferred if g in set(q.stratum)]+sorted(set(q.stratum)-set(preferred))
    names={'WLF':'Woman, Life, Freedom','LionSun_2025_2026':'Lion-and-Sun','comparative_context':'Comparative/context'}
    denominators=q.groupby('stratum').n_sources.first().astype(int)
    a=q.pivot(index='category_id',columns='stratum',values='presence_pct').reindex(cats)[groups]
    fig,ax=plt.subplots(figsize=(10,6.2));im=ax.imshow(a,aspect='auto',cmap='Blues',vmin=0,vmax=100)
    ax.set_yticks(range(len(cats)),[LABELS[x] for x in cats],fontsize=11)
    ax.set_xticks(range(len(groups)),[f'{names.get(g,g)}\n{denominators[g]} sources' for g in groups],fontsize=11)
    for i in range(len(cats)):
      for j in range(len(groups)):ax.text(j,i,f'{a.iloc[i,j]:.1f}',ha='center',va='center',fontsize=10,color='white' if a.iloc[i,j]>65 else NAVY)
    fig.colorbar(im,ax=ax,label='Source mention percentage');ax.set_title('Source coverage differs across periods and contexts',pad=12)
    fig.tight_layout();save(fig,'Figure_S2')
    q=pd.read_csv(N/'calibration_plot_data.csv')
    fig,ax=plt.subplots(figsize=(7.8,5.5))
    for m,col,name in [('logistic',TEAL,'Ridge logistic'),('random_forest',CORAL,'Shallow forest')]:
      z=q[q.model==m];ax.plot(z.mean_probability,z.observed_frequency,'o-',lw=2,color=col,label=name)
    ax.plot([0,1],[0,1],'--',color='#AAB8C2');ax.set(xlim=(0,1),ylim=(0,1),xlabel='Mean held-out predicted probability',ylabel='Observed success proportion',title='Calibration across four probability groups')
    ax.legend(frameon=False);ax.grid(alpha=.16);fig.tight_layout();save(fig,'Figure_S3')

def write_manifest():
    manifest={'event_endpoint':ENDPOINT,'outputs':['Graphical_Abstract']+[f'Figure_{i}' for i in range(1,8)]+[f'Figure_S{i}' for i in range(1,4)],
              'formats':['png','pdf','svg'],'raster_dpi':400,'quantitative_depth':'Figure 2 plots actual SVD coordinates; no decorative 3D on statistical axes.',
              'conceptual_depth':'Shallow layered cards, source pages and a schematic globe; no geographic data encoded.',
              'corpus_summary':corpus_summary(),'navco_summary':navco_summary(),
              'input_hashes':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in
                [C/'corpus_run_summary.json',C/'source_cluster_coordinates.csv',C/'dictionary_summary.csv',C/'cluster_selection.csv',
                 C/'dictionary_strata.csv',N/'run_summary.json',N/'primary_performance.csv',N/'nonviolent_refit_performance_intervals.csv',
                 N/'roc_plot_data.csv',N/'calibration_plot_data.csv']}}
    (OUT/'figure_render_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest-only',action='store_true',help='Refresh input provenance after citation-metadata updates that do not alter plotted values.')
    args=parser.parse_args()
    if not args.manifest_only:
        graphical_abstract();figure1();figure2();figure3();figure4();figure5();figure6();figure7();supplement_figures()
    write_manifest()
    print('Refreshed provenance only' if args.manifest_only else f'Rendered {len(list(OUT.glob("*.png")))} figure PNGs, with PDF and SVG counterparts')
