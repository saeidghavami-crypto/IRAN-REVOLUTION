#!/usr/bin/env python3
"""Reproduce the NAVCO historical outcome analysis without using outcome-year features.

Run from any directory: python code/navco/run_analysis.py --root /path/to/package
All predictions in the main performance table are held out by location country.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import platform
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scipy
import sklearn
from sklearn.base import clone
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    average_precision_score, balanced_accuracy_score, brier_score_loss,
    log_loss, roc_auc_score, roc_curve,
)
from sklearn.model_selection import StratifiedGroupKFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

SEED = 11011
FEATURES = [
    "prim_meth", "camp_size", "camp_confl_intensity", "camp_structure",
    "cdivers", "parall_instit", "repression", "sec_defect",
    "state_defect", "camp_support", "regime_support",
]
LABELS = {
    "prim_meth": "Primarily nonviolent methods",
    "camp_size": "Participation category",
    "camp_confl_intensity": "Internal conflict intensity",
    "camp_structure": "Centralized leadership structure",
    "cdivers": "Any recorded participation diversity",
    "parall_instit": "Parallel institutions",
    "repression": "Repression severity",
    "sec_defect": "Security-force defections",
    "state_defect": "Civilian state-official defections",
    "camp_support": "External state support for campaign",
    "regime_support": "External state support for regime",
}


def dump_json(path: Path, value) -> None:
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")


def models(features=FEATURES):
    # Every imputer/scaler is cloned and fitted only within its training fold.
    return {
        "logistic": Pipeline([
            ("imputer", SimpleImputer(strategy="median", add_indicator=True, keep_empty_features=True)),
            ("scale", StandardScaler()),
            ("classifier", LogisticRegression(C=0.25, solver="lbfgs", max_iter=5000, random_state=SEED)),
        ]),
        "random_forest": Pipeline([
            ("imputer", SimpleImputer(strategy="median", add_indicator=True, keep_empty_features=True)),
            ("classifier", RandomForestClassifier(
                n_estimators=500, max_depth=3, min_samples_leaf=10,
                max_features="sqrt", random_state=SEED, n_jobs=1,
            )),
        ]),
    }


def load_data(root):
    path = root / "data/navco/NAVCO2-1_ForPublication.dta"
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    expected = "a2c30863f021e4cf2aa334d65d3a0f03209c40a8d4f0324f4f886f6cdc6deb76"
    if digest != expected:
        raise ValueError("The source file does not match the pinned official NAVCO release.")
    frame = pd.read_stata(path, convert_categoricals=False).sort_values(["id", "year"]).reset_index(drop=True)
    assert frame.shape == (2717, 102)
    assert frame.id.nunique() == 384
    assert not frame.duplicated(["id", "year"]).any()
    assert frame.year.max() == 2013
    for _, group in frame.groupby("id"):
        assert group.year.diff().dropna().eq(1).all(), "Nonconsecutive source years need review."
    return frame


def assemble(frame, horizon=5, terminal=False):
    onset = frame.drop_duplicates("id").set_index("id").copy()
    final = frame.drop_duplicates("id", keep="last").set_index("id")
    assert onset.year.eq(onset.start_year).all()
    flow = [{"step": "All deposited campaigns", "n": len(onset)}]
    candidate = onset.loc[onset.camp_goals.eq(0)].copy()
    flow.append({"step": "Regime-change goal in onset year", "n": len(candidate)})
    candidate = candidate.loc[candidate.success.eq(0)].copy()
    flow.append({"step": "No coded success in onset year", "n": len(candidate)})
    candidate = candidate.loc[final.loc[candidate.index, "year"].gt(candidate.year)].copy()
    flow.append({"step": "Activity continues into a later calendar year", "n": len(candidate)})
    if terminal:
        candidate = candidate.loc[final.loc[candidate.index, "status"].eq(0)].copy()
        flow.append({"step": "Recorded as ended by administrative endpoint", "n": len(candidate)})
    else:
        candidate = candidate.loc[candidate.year.le(2013 - horizon)].copy()
        flow.append({"step": f"Onset by {2013-horizon}: complete {horizon}-year administrative window", "n": len(candidate)})
    assert candidate.loc_iso.notna().all() and candidate.loc_iso.ne(-99).all()
    candidate["country_group"] = candidate.loc_iso.astype(int).astype(str)
    candidate["onset_year"] = candidate.year.astype(int)
    candidate["final_observed_year"] = final.loc[candidate.index, "year"].astype(int)
    candidate["ongoing_at_2013"] = final.loc[candidate.index, "status"].astype(int)
    candidate["terminal_success"] = final.loc[candidate.index, "success"].astype(int)
    candidate["goal_changed"] = frame.groupby("id").camp_goals.nunique().gt(1).reindex(candidate.index).astype(int)
    if terminal:
        candidate["outcome"] = candidate.terminal_success
    else:
        candidate["outcome"] = [
            int(frame.loc[
                frame.id.eq(i) & frame.year.gt(row.onset_year)
                & frame.year.le(row.onset_year + horizon), "success"
            ].eq(1).any()) for i, row in candidate.iterrows()
        ]
    candidate.index.name = "campaign_id"
    assert candidate.outcome.isin([0, 1]).all()
    candidate[FEATURES] = candidate[FEATURES].replace(-99, np.nan)
    keep = [
        "camp_name", "location", "country_group", "onset_year", "final_observed_year",
        "ongoing_at_2013", "terminal_success", "goal_changed", "outcome",
    ] + FEATURES
    return candidate[keep], pd.DataFrame(flow)


def metrics(y, probability, calibration=True):
    probability = np.clip(np.asarray(probability), 1e-8, 1-1e-8)
    y = np.asarray(y)
    result = {
        "auroc": roc_auc_score(y, probability),
        "average_precision": average_precision_score(y, probability),
        "brier": brier_score_loss(y, probability),
        "log_loss": log_loss(y, probability, labels=[0, 1]),
        "balanced_accuracy_at_0_5": balanced_accuracy_score(y, probability >= 0.5),
    }
    if calibration:
        logits = np.log(probability / (1 - probability)).reshape(-1, 1)
        fit = LogisticRegression(C=1e8, solver="lbfgs", max_iter=5000).fit(logits, y)
        result["calibration_intercept"] = float(fit.intercept_[0])
        result["calibration_slope"] = float(fit.coef_[0, 0])
    return result


def oof(cohort, features=FEATURES, seed=SEED):
    x, y, countries = cohort[features], cohort.outcome.to_numpy(), cohort.country_group.to_numpy()
    cv = StratifiedGroupKFold(n_splits=5, shuffle=True, random_state=seed)
    outputs = cohort[["camp_name", "location", "country_group", "onset_year", "outcome"]].copy()
    for name in ["prevalence", "logistic", "random_forest"]:
        outputs[name] = np.nan
    outputs["fold"] = -1
    fold_rows = []
    for fold, (train, test) in enumerate(cv.split(x, y, countries), 1):
        assert not set(countries[train]) & set(countries[test])
        assert len(np.unique(y[train])) == 2 and len(np.unique(y[test])) == 2
        outputs.iloc[test, outputs.columns.get_loc("prevalence")] = y[train].mean()
        outputs.iloc[test, outputs.columns.get_loc("fold")] = fold
        for name, estimator in models(features).items():
            fit = clone(estimator).fit(x.iloc[train], y[train])
            outputs.iloc[test, outputs.columns.get_loc(name)] = fit.predict_proba(x.iloc[test])[:, 1]
        fold_rows.append({
            "fold": fold, "training_campaigns": len(train), "test_campaigns": len(test),
            "training_countries": len(set(countries[train])), "test_countries": len(set(countries[test])),
            "training_successes": int(y[train].sum()), "test_successes": int(y[test].sum()),
            "country_overlap": 0,
        })
    assert outputs[["prevalence", "logistic", "random_forest"]].notna().all().all()
    return outputs, pd.DataFrame(fold_rows)


def bootstrap_performance(predictions, n_boot=2000):
    rng = np.random.default_rng(SEED + 1)
    country_ids = predictions.country_group.unique()
    rows_by_country = {c: np.flatnonzero(predictions.country_group.to_numpy() == c) for c in country_ids}
    bootstrap = []
    contrasts = []
    y = predictions.outcome.to_numpy()
    for draw in range(n_boot):
        countries = rng.choice(country_ids, size=len(country_ids), replace=True)
        index = np.concatenate([rows_by_country[c] for c in countries])
        if len(np.unique(y[index])) < 2:
            continue
        model_metrics = {}
        for name in ["prevalence", "logistic", "random_forest"]:
            value = metrics(y[index], predictions[name].to_numpy()[index], calibration=False)
            model_metrics[name] = value
            bootstrap.append({"draw": draw, "model": name, **value})
        contrasts.append({
            "draw": draw,
            "logistic_minus_prevalence_brier": model_metrics["logistic"]["brier"]-model_metrics["prevalence"]["brier"],
            "forest_minus_prevalence_brier": model_metrics["random_forest"]["brier"]-model_metrics["prevalence"]["brier"],
            "forest_minus_logistic_brier": model_metrics["random_forest"]["brier"]-model_metrics["logistic"]["brier"],
            "forest_minus_logistic_auroc": model_metrics["random_forest"]["auroc"]-model_metrics["logistic"]["auroc"],
        })
    boot = pd.DataFrame(bootstrap)
    summaries = []
    for name in ["prevalence", "logistic", "random_forest"]:
        observed = metrics(y, predictions[name], calibration=(name != "prevalence"))
        for measure, value in observed.items():
            entry = {"model": name, "metric": measure, "estimate": value}
            if measure in boot.columns:
                low, high = np.quantile(boot.loc[boot.model.eq(name), measure], [0.025, 0.975])
                entry.update({"lower_95": low, "upper_95": high})
            else:
                entry.update({"lower_95": np.nan, "upper_95": np.nan})
            summaries.append(entry)
    contrast_df = pd.DataFrame(contrasts)
    contrast_rows = []
    for column in contrast_df.columns.drop("draw"):
        low, high = np.quantile(contrast_df[column], [0.025, 0.975])
        model_metrics = {name: metrics(y, predictions[name]) for name in ["prevalence", "logistic", "random_forest"]}
        # Match the explicit contrast names to the corresponding full-sample point estimates.
        left, right, measure = {
            "logistic_minus_prevalence_brier": ("logistic", "prevalence", "brier"),
            "forest_minus_prevalence_brier": ("random_forest", "prevalence", "brier"),
            "forest_minus_logistic_brier": ("random_forest", "logistic", "brier"),
            "forest_minus_logistic_auroc": ("random_forest", "logistic", "auroc"),
        }[column]
        contrast_rows.append({"contrast": column, "estimate": model_metrics[left][measure]-model_metrics[right][measure], "lower_95": low, "upper_95": high})
    return pd.DataFrame(summaries), pd.DataFrame(contrast_rows), boot


def coefficient_stability(cohort, n_boot=500):
    x, y = cohort[FEATURES], cohort.outcome.to_numpy()
    estimator = models()["logistic"]
    fit = clone(estimator).fit(x, y)
    # Coefficients are per one training-sample standard deviation after median imputation.
    original = fit.named_steps["classifier"].coef_[0][:len(FEATURES)]
    rng = np.random.default_rng(SEED + 2)
    ids = cohort.country_group.unique()
    groups = {c: np.flatnonzero(cohort.country_group.to_numpy() == c) for c in ids}
    draws = []
    for iteration in range(n_boot):
        chosen = rng.choice(ids, len(ids), replace=True)
        index = np.concatenate([groups[c] for c in chosen])
        if len(np.unique(y[index])) < 2:
            continue
        bootstrap_fit = clone(estimator).fit(x.iloc[index], y[index])
        coef = bootstrap_fit.named_steps["classifier"].coef_[0][:len(FEATURES)]
        draws.append(coef)
    values = np.asarray(draws)
    rows = []
    for i, feature in enumerate(FEATURES):
        low, high = np.quantile(values[:, i], [0.025, 0.975])
        rows.append({
            "feature": feature, "label": LABELS[feature],
            "standardized_ridge_coefficient": original[i],
            "bootstrap_2_5_percentile": low, "bootstrap_97_5_percentile": high,
            "bootstrap_positive_fraction": float(np.mean(values[:, i] > 0)),
            "bootstrap_negative_fraction": float(np.mean(values[:, i] < 0)),
            "warning": "Descriptive regularized associations; bootstrap ranges are not causal confidence intervals or hypothesis tests",
        })
    return pd.DataFrame(rows), pd.DataFrame(values, columns=FEATURES)


def sensitivities(frame, cohort):
    rows, predictions = [], {}
    cohort3 = cohort.copy()
    cohort3["outcome"] = [int(frame.loc[
        frame.id.eq(i) & frame.year.gt(row.onset_year) & frame.year.le(row.onset_year+3), "success"
    ].eq(1).any()) for i, row in cohort3.iterrows()]
    terminal, _ = assemble(frame, terminal=True)
    specs = {
        "three_year_same_cohort": (cohort3, FEATURES),
        "unchanged_goals": (cohort.loc[cohort.goal_changed.eq(0)], FEATURES),
        "nonviolent_onset": (cohort.loc[cohort.prim_meth.eq(1)], FEATURES),
        "terminal_ended_campaigns": (terminal, FEATURES),
        "exclude_defection_predictors": (cohort, [f for f in FEATURES if f not in ["sec_defect", "state_defect"]]),
    }
    for name, (data, features) in specs.items():
        pred, _ = oof(data, features)
        predictions[name] = pred
        for model in ["prevalence", "logistic", "random_forest"]:
            rows.append({"analysis": name, "model": model, "n": len(data), "countries": data.country_group.nunique(), "successes": int(data.outcome.sum()), **metrics(pred.outcome, pred[model], calibration=(model != "prevalence"))})
    return pd.DataFrame(rows), predictions


def temporal_evaluation(cohort):
    rows, saved = [], {}
    test = cohort.loc[cohort.onset_year.ge(1990)]
    # A pre-1990 forecast can only train on labels observable before 1990.
    # Purge 1985-1989 onsets because their five-year outcome windows cross the cutoff.
    before = cohort.loc[(cohort.onset_year + 5).lt(1990)]
    for version in ["temporal_only", "temporal_and_unseen_country"]:
        train = before.copy()
        if version.endswith("unseen_country"):
            train = train.loc[~train.country_group.isin(test.country_group)]
            assert not set(train.country_group) & set(test.country_group)
        pred = test[["camp_name", "location", "country_group", "onset_year", "outcome"]].copy()
        pred["prevalence"] = train.outcome.mean()
        for name, estimator in models().items():
            fit = clone(estimator).fit(train[FEATURES], train.outcome)
            pred[name] = fit.predict_proba(test[FEATURES])[:, 1]
        for name in ["prevalence", "logistic", "random_forest"]:
            rows.append({
                "analysis": version, "model": name,
                "training_n": len(train), "test_n": len(test),
                "training_countries": train.country_group.nunique(), "test_countries": test.country_group.nunique(),
                "training_successes": int(train.outcome.sum()), "test_successes": int(test.outcome.sum()),
                "country_overlap": len(set(train.country_group) & set(test.country_group)),
                **metrics(test.outcome, pred[name], calibration=(name != "prevalence")),
            })
        saved[version] = pred
    return pd.DataFrame(rows), saved


def plots(out, predictions, metrics_table, coefficients):
    palette = {"logistic": "#164A63", "random_forest": "#C17B2E", "prevalence": "#91989B"}
    names = {"logistic": "Regularized logistic", "random_forest": "Shallow random forest", "prevalence": "Training prevalence"}
    fig, axes = plt.subplots(1, 2, figsize=(10, 4.2), layout="constrained")
    roc_data, cal_data = [], []
    for model in ["logistic", "random_forest"]:
        fpr, tpr, _ = roc_curve(predictions.outcome, predictions[model])
        score = roc_auc_score(predictions.outcome, predictions[model])
        axes[0].plot(fpr, tpr, color=palette[model], lw=2, label=f"{names[model]} (AUC {score:.2f})")
        roc_data += [{"model": model, "false_positive_rate": f, "true_positive_rate": t} for f,t in zip(fpr,tpr)]
        bins = pd.qcut(predictions[model], q=4, duplicates="drop")
        summary = predictions.assign(bin=bins).groupby("bin", observed=True).agg(mean_probability=(model,"mean"), observed_frequency=("outcome","mean"), n=("outcome","size"))
        axes[1].plot(summary.mean_probability, summary.observed_frequency, marker="o", lw=1.5, color=palette[model], label=names[model])
        cal_data += [{"model": model, "bin": str(index), **row.to_dict()} for index,row in summary.iterrows()]
    for ax in axes:
        ax.plot([0,1],[0,1],ls="--",lw=1,color="#A0A0A0")
        ax.spines[["right","top"]].set_visible(False)
        ax.set_xlim(0,1); ax.set_ylim(0,1)
        ax.legend(fontsize=8, frameon=False, loc="lower right")
    axes[0].set(xlabel="False-positive rate", ylabel="True-positive rate", title="A  Country-held-out discrimination")
    axes[1].set(xlabel="Mean predicted probability", ylabel="Observed five-year success fraction", title="B  Descriptive calibration by quartile")
    fig.suptitle("Historical regime-change campaigns active after their onset year", fontsize=11)
    fig.savefig(out/"navco_validation.png",dpi=400,bbox_inches="tight")
    fig.savefig(out/"navco_validation.pdf",bbox_inches="tight")
    plt.close(fig)
    pd.DataFrame(roc_data).to_csv(out/"roc_plot_data.csv",index=False)
    pd.DataFrame(cal_data).to_csv(out/"calibration_plot_data.csv",index=False)
    table = coefficients.sort_values("standardized_ridge_coefficient")
    fig, ax = plt.subplots(figsize=(8.5,5.6),layout="constrained")
    x = table.standardized_ridge_coefficient.to_numpy()
    lo = table.bootstrap_2_5_percentile.to_numpy(); hi = table.bootstrap_97_5_percentile.to_numpy()
    y = np.arange(len(table))
    ax.hlines(y,lo,hi,color="#8CA5B1",lw=2)
    ax.scatter(x,y,color="#164A63",s=30,zorder=3)
    ax.set_yticks(y,table.label,fontsize=9)
    ax.axvline(0,color="#999999",lw=1,ls="--")
    ax.set_xlabel("Standardized regularized coefficient (descriptive)")
    ax.set_title("Onset-year associations with five-year coded success",fontsize=11)
    ax.spines[["right","top"]].set_visible(False)
    fig.savefig(out/"navco_associations.png",dpi=400,bbox_inches="tight")
    fig.savefig(out/"navco_associations.pdf",bbox_inches="tight")
    plt.close(fig)


def manuscript_table(results):
    entries=[]
    labels={"prevalence":"Training-fold prevalence", "logistic":"Regularized logistic regression", "random_forest":"Restricted random forest"}
    for model in labels:
        selected=results.loc[results.model.eq(model)].set_index("metric")
        entry={"Model":labels[model]}
        for measure,title in [("auroc","AUROC (95% interval)"),("average_precision","Average precision (95% interval)"),("brier","Brier score (95% interval)"),("balanced_accuracy_at_0_5","Balanced accuracy at 0.5 (95% interval)")]:
            row=selected.loc[measure]
            entry[title]=f"{row.estimate:.3f} ({row.lower_95:.3f}–{row.upper_95:.3f})"
        if model=="prevalence":
            entry["AUROC (95% interval)"]="Not interpreted"
        for measure,title in [("calibration_intercept","Calibration intercept"),("calibration_slope","Calibration slope")]:
            entry[title]=f"{selected.loc[measure,'estimate']:.3f}" if measure in selected.index else "Not applicable"
        entries.append(entry)
    return pd.DataFrame(entries)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--root",type=Path,default=Path(__file__).resolve().parents[2])
    parser.add_argument("--bootstrap",type=int,default=2000)
    parser.add_argument("--coefficient-bootstrap",type=int,default=500)
    args=parser.parse_args()
    root=args.root.resolve(); out=root/"outputs/navco"; out.mkdir(parents=True,exist_ok=True)
    frame=load_data(root); cohort,flow=assemble(frame)
    cohort.to_csv(out/"campaign_analysis_data.csv")
    flow["removed_at_step"]=flow.n.shift(1)-flow.n
    flow.to_csv(out/"cohort_flow.csv",index=False)
    missing=pd.DataFrame({"feature":FEATURES,"label":[LABELS[f] for f in FEATURES],"missing_n":[int(cohort[f].isna().sum()) for f in FEATURES],"missing_percent":[100*cohort[f].isna().mean() for f in FEATURES]})
    missing.to_csv(out/"predictor_missingness.csv",index=False)
    print(f"Primary cohort: {len(cohort)} campaigns, {cohort.country_group.nunique()} country groups, {cohort.outcome.sum()} successes",flush=True)
    pred,folds=oof(cohort)
    pred.to_csv(out/"country_heldout_predictions.csv")
    folds.to_csv(out/"validation_folds.csv",index=False)
    results,contrasts,boot=bootstrap_performance(pred,args.bootstrap)
    results.to_csv(out/"primary_performance.csv",index=False)
    manuscript_table(results).to_csv(out/"manuscript_model_table.csv",index=False)
    contrasts.to_csv(out/"performance_contrasts.csv",index=False)
    boot.to_csv(out/"performance_bootstrap.csv",index=False)
    print(results.to_string(index=False),flush=True)
    sens,senspred=sensitivities(frame,cohort)
    sens.to_csv(out/"sensitivity_performance.csv",index=False)
    for name, values in senspred.items(): values.to_csv(out/f"predictions_{name}.csv")
    nv_metrics,nv_contrasts,_=bootstrap_performance(senspred["nonviolent_onset"],args.bootstrap)
    nv_metrics.to_csv(out/"nonviolent_refit_performance_intervals.csv",index=False)
    nv_contrasts.to_csv(out/"nonviolent_refit_contrasts.csv",index=False)
    temporal,temppred=temporal_evaluation(cohort)
    temporal.to_csv(out/"temporal_performance.csv",index=False)
    for name, values in temppred.items(): values.to_csv(out/f"predictions_{name}.csv")
    coef,coefboot=coefficient_stability(cohort,args.coefficient_bootstrap)
    coef.to_csv(out/"descriptive_coefficients.csv",index=False)
    coefboot.to_csv(out/"coefficient_bootstrap.csv",index=False)
    plots(out,pred,results,coef)
    versions={"python":platform.python_version(),"numpy":np.__version__,"pandas":pd.__version__,"scipy":scipy.__version__,"scikit_learn":sklearn.__version__,"matplotlib":matplotlib.__version__}
    summary={
        "source_campaigns":384,"source_campaign_years":2717,"source_min_year":1945,"source_max_year":2013,
        "primary_n":len(cohort),"primary_country_groups":int(cohort.country_group.nunique()),"primary_successes":int(cohort.outcome.sum()),
        "primary_ongoing_at_2013":int(cohort.ongoing_at_2013.sum()),"primary_goals_changed":int(cohort.goal_changed.sum()),
        "primary_violent_onset":int(cohort.prim_meth.eq(0).sum()),"primary_nonviolent_onset":int(cohort.prim_meth.eq(1).sum()),
        "performance_bootstrap_draws":args.bootstrap,"coefficient_bootstrap_draws":args.coefficient_bootstrap,
        "versions":versions,
        "outcome_warning":"No coded maximalist success within five years does not mean permanent failure, and maximalist success is not a measure of later democratic governance.",
        "transport_warning":"No calibrated prediction or numerical feature profile is constructed for either Iranian revolution."
    }
    dump_json(out/"run_summary.json",summary)
    print("Saved reproducible outputs to",out,flush=True)


if __name__=="__main__":
    main()
