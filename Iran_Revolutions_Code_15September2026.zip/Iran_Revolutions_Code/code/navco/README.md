# NAVCO historical outcome analysis

This code asks whether conditions recorded in a campaign's first calendar year help distinguish campaigns that achieve a coded maximalist goal within the next five years. It uses actual historical campaign outcomes. It does not generate success probabilities for the Woman, Life, Freedom revolution or the Lion-and-Sun Revolution.

## What you need

Python 3.12 and the packages listed in `requirements.txt`. The exact versions used are also recorded in `outputs/navco/run_summary.json`. Python 3.12.14 was used for the supplied results.

From the project root:

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r code/navco/requirements.txt
python code/navco/download_data.py
python code/navco/run_analysis.py
```

On Windows, activate the environment with `.venv\Scripts\activate`. If the project root is not inferred correctly, pass `--root /full/path/to/project` to either script.

The analysis uses fixed random seeds and fixed model settings. It usually takes a few minutes. For a quick installation check, `--bootstrap 50 --coefficient-bootstrap 20` reduces the resampling workload, but these shortened outputs must not replace the publication results. Publication outputs use 2,000 country-bootstrap samples for performance and 500 for descriptive coefficient stability.

## Data and provenance

The source is Chenoweth and Shay's NAVCO 2.1 Dataset, Harvard Dataverse, DOI https://doi.org/10.7910/DVN/MHOXDV, deposited version 2.1. The source data and codebook are licensed CC0 1.0. Download URLs and SHA-256 checksums are pinned in `download_data.py`; `data/navco/source_manifest.json` records the files used. Do not replace them silently with a newer release.

The downloaded Stata file contains 2,717 campaign-years and 384 distinct campaigns from 1945 to 2013. This count matches the deposited metadata and codebook. The accompanying journal article's abstract mentions 389 campaigns; the analysis uses the actual deposited file, not that abstract's count. Some codebook boilerplate refers to 2017. The supplied file's maximum year and censor-variable label identify the administrative cutoff as 2013, which the code enforces.

Source publications:

- Chenoweth E, Shay CW. NAVCO 2.1 Dataset. Harvard Dataverse. https://doi.org/10.7910/DVN/MHOXDV
- Chenoweth E, Shay CW. Updating nonviolent campaigns: Introducing NAVCO 2.1. Journal of Peace Research. 2022;59(6):876–889. https://doi.org/10.1177/00223433221092938

## One observation means one campaign

The primary cohort contains 127 campaigns in 75 location-country ISO groups. The cohort is restricted to campaigns that:

1. Have a regime-change goal in their onset year.
2. Have not already achieved coded success in that year.
3. Continue into at least one later calendar year.
4. Begin by 2008, allowing a full five-year outcome window by the 2013 data cutoff.

This excludes rapid successes and rapid failures confined to one calendar year. It therefore addresses campaigns continuing beyond onset, not all revolutions. NAVCO also selects campaigns that meet its organizational definition and reach at least 1,000 participants at some point. It is not a representative sample of every protest or attempted revolution.

The outcome is a success record in one of the five calendar years after onset. A zero means no such success within that window. It does not mean the campaign failed permanently. Ongoing campaigns can enter the analysis if their entire five-year window is observed. Thirteen primary-cohort campaigns were still ongoing at the dataset cutoff.

NAVCO success denotes achievement of a stated maximalist goal. It does not establish democratic consolidation, rights protection, a durable political settlement, or success for every faction. Ten eligible campaigns changed their recorded goals during their history. The unchanged-goal sensitivity addresses this difference without rewriting the source labels.

## Predictors and leakage controls

All 11 predictors come from the onset-year row: primary resistance method, participation category, internal conflict, leadership structure, recorded diversity, parallel institutions, repression, security defections, civilian state-official defections, external state support for the campaign, and external state support for the regime. The exact coding is provided in `data/navco/predictor_dictionary.csv` and the official codebook.

No terminal-year measurements, final campaign duration, outcome/progress scores, campaign-wide maxima, country identities, or campaign names enter the predictive models. Missing values coded −99 are converted to missing data. Median imputation, missing-value indicators, and standardization are fitted inside training folds. Outcomes are never imputed.

The model settings were chosen without hyperparameter optimization: ridge logistic regression uses C=0.25; the comparison forest uses 500 trees, depth at most 3, and at least 10 observations per leaf. The forest is a limited nonlinear comparison, not a proposed new algorithm. Neither model uses class weighting or a fitted decision threshold. A training-fold prevalence predictor supplies the probability baseline.

## Validation and statistics

Five-fold stratified group cross-validation holds out entire location-country ISO groups. Campaigns in a held-out country are absent from that fold's training data. Each campaign receives one out-of-fold probability. Country codes are used for grouping only.

The main metrics are AUROC, average precision, Brier score, log loss, and balanced accuracy at the fixed 0.5 threshold. Discrimination and probability accuracy are reported separately. Calibration intercept and slope are estimated jointly by logistic regression of outcome on the logit of held-out probabilities. They are descriptive, uncorrected calibration diagnostics; the intercept is not a separate offset-based calibration-in-the-large estimate. Calibration coefficients are not reported for the prevalence benchmark.

For performance uncertainty, 2,000 bootstrap resamples draw whole country groups with replacement, retaining all campaigns in each sampled group. These intervals condition on the fitted cross-validation predictions. They do not include the full uncertainty of retraining the models or selecting a different fold allocation. Bootstrap model contrasts use the same resampled countries for both models.

The full-cohort logistic coefficients are descriptive, regularized associations per standard deviation after imputation. Five hundred country-bootstrap refits describe their sign stability. Their percentile ranges are not causal confidence intervals, significance tests, or estimates of what an intervention would accomplish.

Sensitivity analyses retain the same model settings. They use a three-year outcome in the same cohort; exclude campaigns with goal changes; refit within the primarily nonviolent onset subset; use terminal outcomes among ended campaigns; and omit the two defection predictors. The nonviolent subset analysis retrains models within 47 campaigns. It is not simply a subset of the pooled model's predictions.

Temporal evaluation trains only on campaigns beginning by 1984, so their complete five-year labels are observable by 1989, and tests on campaigns beginning from 1990 onward. Onsets in 1985–1989 are purged from training because their label windows overlap the later period. A stricter version also removes training countries represented in the later test set. Test outcomes are never used to recalibrate predictions.

## Main files to inspect

- `outputs/navco/cohort_flow.csv`: inclusion and exclusion counts.
- `outputs/navco/campaign_analysis_data.csv`: one analysis row per campaign, with onset-year features and the future outcome.
- `outputs/navco/primary_performance.csv`: country-held-out estimates and country-bootstrap intervals.
- `outputs/navco/performance_contrasts.csv`: paired bootstrap differences in predictive performance.
- `outputs/navco/country_heldout_predictions.csv`: the prediction and fold for every campaign.
- `outputs/navco/sensitivity_performance.csv`: all specified sensitivity results.
- `outputs/navco/nonviolent_refit_performance_intervals.csv`: uncertainty for the small nonviolent-only refit.
- `outputs/navco/temporal_performance.csv`: later-period transport checks.
- `outputs/navco/descriptive_coefficients.csv`: coefficient directions and bootstrap stability.
- `outputs/navco/predictor_missingness.csv`: missing values before imputation.
- `outputs/navco/validation_folds.csv`: sample sizes and zero country overlap for each fold.
- `outputs/navco/roc_plot_data.csv` and `calibration_plot_data.csv`: exact values underlying the figures.

## How to interpret the results

The models test whether historical early campaign conditions carry predictive information about later coded outcomes. They cannot establish why a particular Iranian revolution did not transfer state power. They also cannot identify conditions that are individually necessary or jointly sufficient for a future transition.

The two Iranian revolutions occur after the source dataset's time period, have no validated feature profiles in this dataset, and are not scored. A useful association in the pooled historical sample does not establish calibration in present-day Iran. The nonviolent-only sensitivity and temporal evaluation are important checks on that limitation. Mechanistic interpretation should remain tied to independently documented historical evidence and should distinguish an unobserved outcome from a proven causal explanation.
