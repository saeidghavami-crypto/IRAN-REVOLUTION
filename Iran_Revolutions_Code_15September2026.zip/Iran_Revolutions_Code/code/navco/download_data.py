#!/usr/bin/env python3
"""Download pinned, publicly licensed NAVCO files from Harvard Dataverse.

Existing files are checked, not silently replaced. No credentials are needed.
"""
import argparse
import hashlib
import json
from pathlib import Path
from urllib.request import Request, urlopen

FILES = [
    ("NAVCO2-1_ForPublication.dta", "https://dataverse.harvard.edu/api/access/datafile/3620879?format=original", "a2c30863f021e4cf2aa334d65d3a0f03209c40a8d4f0324f4f886f6cdc6deb76"),
    ("NAVCO2-1_ForPublication.xls", "https://dataverse.harvard.edu/api/access/datafile/3620878", "b28dc2f9a00bcc2fd2629f1c966d95326b1240a305671385eed5f388d35b9d6d"),
    ("NAVCO_2.1_codebook.pdf", "https://dataverse.harvard.edu/api/access/datafile/3648624", "6fe8faa4c6ad45c74d61082d6aedc780d5440a7ace25747a63eaf338951c9a93"),
]

def retrieve(url):
    request=Request(url,headers={"User-Agent":"Mozilla/5.0"})
    with urlopen(request,timeout=90) as response:
        return response.read()

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--root",type=Path,default=Path(__file__).resolve().parents[2])
    args=parser.parse_args()
    folder=args.root.resolve()/"data/navco";folder.mkdir(parents=True,exist_ok=True)
    for name,url,expected in FILES:
        destination=folder/name
        data=destination.read_bytes() if destination.exists() else retrieve(url)
        found=hashlib.sha256(data).hexdigest()
        if found!=expected:
            raise ValueError(f"Pinned checksum mismatch for {name}; inspect source changes before proceeding.")
        if not destination.exists():
            destination.write_bytes(data)
        print(f"Verified {name}: {found}")
    metadata=folder/"dataverse_metadata.json"
    if not metadata.exists():
        data=retrieve("https://dataverse.harvard.edu/api/datasets/:persistentId/?persistentId=doi:10.7910/DVN/MHOXDV")
        json.loads(data)
        metadata.write_bytes(data)

if __name__=="__main__":
    main()
