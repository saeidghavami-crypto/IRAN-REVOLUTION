# Source-level text analysis

This part of the project maps the documents used in the evidence synthesis. It
does not train a classifier of successful and unsuccessful revolutions. A source
is the unit of analysis here; campaign-level outcome modelling is a separate
component of the study.

## What the analysis does

The source register accounts for every reference in the 205-source evidence
register. The text analysis includes 182 sources with complete English text or a
complete, explicitly bounded English contribution within a larger file. Sources
available only as an abstract, partial text, bibliographic record or inaccessible
statement remain in the register and bibliography. Non-English sources and three
methodological references are also outside this English substantive-text model.
No title or abstract is treated as a complete paper.

The final bibliography contains 208 entries: the 205 core source identities plus
three linked correction notices (R182, R183 and R184). The notices are ancillary
publication records, not additional documents in the text model. They do not
increase either the 205-source register or the 182-source analytical denominator.

## Source identifiers and final citation numbers

`reference_id` (for example, R006) is a stable source identifier. It does not
necessarily equal a bracketed citation number in the final article. The file
`references/reference_crosswalk.csv`, relative to the project root, is the
authoritative mapping. The corpus scripts read it automatically and keep exactly
their registered source rows; they never append correction notices as texts.

- `source_register_number` preserves the sequence in the 205-source register.
- `final_reference_number` is the number in the final 208-entry bibliography.
- `current_reference_number` is retained as a compatibility alias and now means
  exactly the same thing as `final_reference_number`.

Use stable identifiers to join analytical tables and current final citation numbers to cite the manuscript. A replacement crosswalk can be passed with `--reference-crosswalk`;
the scripts reject missing identities, duplicate bibliography numbers, or a
correction notice included as a corpus source. Input and crosswalk hashes are
recorded in the run summaries.

The program represents the texts with TF-IDF, reduces that representation with
truncated SVD, and explores K-means partitions. It also counts explicit mentions
in 14 published term lists. These operations describe the vocabulary and coverage
of the evidence base. They do not measure the strength of political mechanisms,
the intentions of participants, the number of independent historical observations,
or the probability of institutional transition.

## Required software

Use Python 3.10 or newer. Install the packages in `requirements.txt`. PDF recovery
also requires the `pdftotext` command from Poppler and Tesseract with English
language data for the one recorded scanned contribution. The run summary records
the exact Python, NumPy, pandas, SciPy and scikit-learn versions used.

## Inputs and private source text

Run the commands below from the study root, which contains `code/`, `outputs/`
and a private local `private/` directory.

1. Obtain the source versions listed in `code/corpus/inputs/source_register.csv`. The PDF
   extraction plan identifies the original numbered files, their SHA-256 hashes,
   the source identities represented by those files, and any page or column
   boundaries. Put the numbered PDFs in `private/original_pdfs/`.
2. There are 118 original numbered PDFs, 1–119 with 33 absent. PDF 89 is an
   additional copy of the same source as PDF 52. The extraction plan consumes
   117 distinct source identities and does not count that copy again.
3. Recover the bounded source text from those PDFs:

```bash
python code/corpus/extract_sources.py \
  --plan code/corpus/inputs/pdf_extraction_plan.json \
  --pdf-dir private/original_pdfs \
  --private-text-dir private/source_texts \
  --log-csv outputs/corpus/pdf_extraction_log.csv
```

4. Recover additional public sources using the 72 documented version-specific
   extraction recipes, source URLs, boundaries and hashes:

```bash
python code/corpus/recover_additional_sources.py \
  --recipes code/corpus/inputs/additional_source_recipes.json \
  --raw-dir private/retrieval \
  --output-dir private/source_texts \
  --download
```

The second command can instead read already obtained raw files if `--download`
is omitted. It does not bypass subscriptions or access controls. Some URLs may
change or become unavailable. If a source cannot be obtained, report that fact;
do not substitute a search snippet, title, abstract or invented text. Exact
reproduction requires the registered selected text. A missing source does not
silently change the denominator.

The recovery instructions verify hashes. Volatile navigation or advertisements
may change the binary HTML while the complete extracted article body remains
identical; the body hash is decisive for these HTML articles. PDF and DOCX source
versions are checked separately. A substantively changed text is rejected by
default. The optional `--allow-source-change` flag is only for inspection of a
new version in a separate output directory; it is not permission to include that
version in the registered analysis. Its identity, scope, completeness and new
hash must first be reviewed and documented.

An explicit selector excludes unrelated promotional sections from the ABC7
Los Angeles article (R047). The retained text is its complete substantive report.
The extraction record is a record of the article's identity and scope; it does
not establish the truth of every assertion made by that report.

Full texts, downloaded PDF/HTML/DOCX/XML files, and page-level extracted text are
private inputs. They are deliberately not redistributed with the public code.
The public package supplies metadata, source URLs, boundaries, hashes, term
lists, methods, and derived numerical outputs. Reusers must obtain source texts
under the terms applicable to those sources.

## Run the text mapping

```bash
python code/corpus/analyze_corpus.py \
  --study-root . \
  --source-register code/corpus/inputs/source_register.csv \
  --lexicon code/corpus/inputs/dictionaries.json \
  --reference-crosswalk references/reference_crosswalk.csv \
  --publication-cutoff 2026-09-15 \
  --out outputs/corpus
```

The program stops if an eligible file is missing, its hash differs, the register
contains a duplicate source identity, an incomplete or non-English source is
marked eligible, or two included texts have the same normalized-text hash. It
does not apply cumulative duplicate discounts or arbitrary quality weights.

## Text representation and cluster selection

Normalization uses Unicode NFKC, preserves Unicode letters, removes soft hyphens,
repairs hyphenated line wraps, normalizes quotation marks and dashes, removes URLs
and email addresses, and collapses whitespace. It does not translate sources,
stem words, or erase non-Latin characters. Bibliography material inside a selected
source remains included unless it lies outside an explicitly recorded source
boundary. This can influence lexical similarity and is a limit of the mapping.

The main TF-IDF model uses unigrams and bigrams, English stop-word removal,
sublinear term frequency, L2 document normalization, minimum document frequency
2, maximum document frequency 95%, and at most 7,000 features. Truncated SVD uses
35 dimensions, 10 power iterations and random seed 42. K-means uses those 35
coordinates directly, Euclidean distance, the Lloyd algorithm and 50 initializations.

For each k from 2 through 10, partitions are fitted with seeds 0, 1, 2, 3 and 42.
The largest mean silhouette across these five seeds selects k; an exact tie is
resolved in favor of smaller k. The seed-42 partition supplies the displayed
source assignments. Cluster numbers are neutral identifiers ordered by the
lowest registered source ID in each cluster. Top terms are derived from fitted
centroids; substantive cluster names are not assigned in advance.

The full silhouette selection table and every seed-specific result are supplied.
Stability is summarized by all ten pairwise adjusted Rand indices among the five
selected-k partitions. These are diagnostics of this lexical partition, not
out-of-sample political validation. The 3D plot uses the actual first three SVD
coordinates. It is only a projection of the 35-dimensional space used for fitting.

Sensitivity analyses exclude contextual background, restrict the corpus to
the two Iranian cases, retain sources with documented publication before the
15 September 2026 cutoff, change SVD dimensionality to 16 or 64, or use unigrams
only. These analyses repeat k selection at the common seed 42 and report adjusted
Rand agreement with the main solution on shared sources. They deliberately do
not call a changed partition a new political finding.

## Dictionary coverage, co-occurrence and source composition

`inputs/dictionaries.json` discloses all 14 term lists. The lists are retained
verbatim from the supplied analysis specification; neutral display labels
describe their vocabulary. Matching uses case-insensitive exact phrases with
word boundaries after normalization. A source contributes once to a category's
presence count if any listed phrase occurs. Counts per 10,000 normalized words
are auxiliary descriptive measures. Unlisted synonyms and plural forms may be
missed. There is no claim that this dictionary has been validated against expert
annotation.

Each source has equal weight in the main coverage estimates. Jaccard co-occurrence
is the number of sources mentioning both categories divided by the number
mentioning either category. Categories share some terms and are not independent.
Neither high co-occurrence nor frequent mentions establish a causal relationship.
Zero matches cannot establish absence of an event or mechanism.

Coverage is supplied by source role, case/period and documented publication genre.
Additional summaries exclude contextual background, restrict to the Iranian cases,
exclude actor statements, retain scholarly analysis only, or retain whole sources
only. A case-balanced sensitivity gives the WLF and Lion-and-Sun source groups
equal total weight; this changes the composition of a textual summary, not the
number of political cases. A provenance-family sensitivity assigns equal total
weight to recorded source families. Provenance grouping flags overlap but cannot
guarantee independent underlying observations. An additional summary gives each
of the six documented genre groups equal total weight. These are descriptive
reweightings, not independent replication or correction of all reporting bias.

The analysis does not perform inferential significance tests on mention counts.
The sources are purposively assembled, unequal in length and genre, and often
draw on shared events or reports. Source counts are descriptive denominators.

## Publication timing and event coverage

The event-analysis endpoint is 15 September 2026. Later sources can provide
retrospective evidence about events within that interval without extending the
outcome window. Bibliographic dates are recorded separately from verified first
online publication when different. Publication-date evidence is retained in the
source register.

For the publication-cutoff sensitivity, day-level dates are used only when
verified. A month represents its full calendar interval and a year its full year.
Eligibility requires the interval's upper end to be on or before the cutoff,
without an unresolved availability qualification. Unknown dates, intervals
crossing the cutoff, later publication or unverified first availability are
excluded from this sensitivity only. The sensitivity contains 180 texts.
R026 has a 14 September report date and 21 September official issuance, but the
registered advance version's earlier availability is unverified. R164 is undated.
R034 is retained using its verified 4 June 2025 online date, despite a 2026 issue.

Publication dates cannot replace event dates. A matched post-onset-window analysis
was not performed because reliable event-coverage intervals were not documented
for every source. No missing event dates were imputed. Case coverage remains
uneven: 94 WLF, 40 Lion-and-Sun and 48 comparative/contextual full texts. Source
counts do not increase the number of independent Iranian cases or campaign rows.

## Main output files

| File | Contents |
| --- | --- |
| `source_manifest.csv` | All registered sources, eligibility, role, genre, scope and actual text counts |
| `references/reference_crosswalk.csv` (project root) | Stable source identifiers, source-register sequence, final bibliography numbering and ancillary correction-notice links |
| `source_coverage.csv` | Accounting by access, language, role, period, genre and publication timing |
| `supplementary_source_accounting.csv` | Registered and eligible source counts for documented strata |
| `source_cluster_coordinates.csv` | Source assignments and all 35 SVD coordinates; first three are the 3D figure data |
| `cluster_selection.csv` | Mean and range of silhouette over five seeds at each candidate k |
| `cluster_selection_runs.csv` | Every k/seed combination |
| `cluster_seed_stability.csv` | Pairwise adjusted Rand indices at selected k |
| `cluster_terms.csv` | Source counts and fitted centroid terms for neutral cluster IDs |
| `cluster_composition.csv` | Source-role, case and genre composition of clusters |
| `cluster_metadata_association.csv` | Descriptive association between partition and metadata |
| `clustering_sensitivity.csv` | Corpus and feature-specification sensitivity |
| `dictionary_summary.csv` | Fourteen-category source-level coverage |
| `dictionary_source_counts.csv` | Per-source counts and normalized frequencies |
| `dictionary_term_counts.csv` | Counts for each listed matched phrase; no source passages |
| `dictionary_cooccurrence.csv` | Pairwise intersections, unions and Jaccard values |
| `dictionary_strata.csv` | Category coverage within source strata |
| `dictionary_sensitivity.csv` | Category coverage under source-composition sensitivities |
| `high_similarity_pairs.csv` | Similarity flags for review, not automatic deletion |
| `corpus_run_summary.json` | Exact input hashes, parameters, software versions and key numerical diagnostics |

## Connecting this module to the research questions

The text model identifies which subjects the assembled documents cover and how
that coverage depends on source composition. A separate source-linked case
comparison establishes what is actually documented about each Iranian revolution.
The campaign-level outcome model tests associations in independent historical
campaign records. Do not merge the document rows with campaign rows as if they
were interchangeable observations. Do not convert category frequencies, cluster
membership or source-query similarity into causal mechanism scores or a forecast
for Iran. A successful retrospective explanation still requires careful reading
of the relevant source passages, attention to contrary evidence, and explicit
distinction between observed facts and interpretation.
