#!/usr/bin/env python3
"""Extract explicitly bounded source texts; never publish the extracted texts.

The JSON plan records PDF identity, page bounds and, where needed, reviewed
column rectangles. Full source text and page/block locators go to a private
directory; only the extraction log is suitable for the public code package.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import re
import shutil
import subprocess
import sys
from collections import defaultdict
from pathlib import Path

import fitz
from reference_mapping import load_reference_mapping, map_source_records


def sha256(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def write_csv(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]) if rows else [])
        writer.writeheader()
        writer.writerows(rows)


def add_segment(segments: list[dict], text: str, page: int, region: str,
                method: str, bbox: list[float] | None = None) -> None:
    text = text.replace("\r\n", "\n").strip()
    if not text:
        return
    segments.append({"page": page, "region_id": region, "bbox_pdf_points": bbox,
                     "extraction_method": method, "text": text,
                     "text_sha256": sha256(text.encode("utf-8"))})


def ocr_region(page: fitz.Page, rect: list[float], private_work: Path,
               reference: str, page_number: int, region_id: str) -> list[tuple[str, list[float]]]:
    if not shutil.which("tesseract"):
        raise ValueError("Tesseract with English language data is required for the OCR source.")
    scale = 3.0
    clip = fitz.Rect(rect)
    image_path = private_work / f"{reference}_p{page_number}_{region_id}.png"
    page.get_pixmap(matrix=fitz.Matrix(scale, scale), clip=clip, alpha=False).save(image_path)
    result = subprocess.run(["tesseract", str(image_path), "stdout", "-l", "eng", "--psm", "3", "tsv"],
                            check=True, capture_output=True, text=True)
    groups: dict[tuple, list[dict]] = defaultdict(list)
    for token in csv.DictReader(io.StringIO(result.stdout), delimiter="\t"):
        if token.get("level") == "5" and token.get("text", "").strip():
            groups[(token["block_num"], token["par_num"])].append(token)
    output = []
    for tokens in groups.values():
        lines: dict[str, list[str]] = defaultdict(list)
        for token in tokens:
            lines[token["line_num"]].append(token["text"])
        text = "\n".join(" ".join(words) for words in lines.values())
        x0 = min(int(t["left"]) for t in tokens) / scale + clip.x0
        y0 = min(int(t["top"]) for t in tokens) / scale + clip.y0
        x1 = max(int(t["left"]) + int(t["width"]) for t in tokens) / scale + clip.x0
        y1 = max(int(t["top"]) + int(t["height"]) for t in tokens) / scale + clip.y0
        output.append((text, [round(x0, 3), round(y0, 3), round(x1, 3), round(y1, 3)]))
    return output


def extract(plan_path: Path, pdf_dir: Path, text_dir: Path, log_path: Path,
            only: set[str] | None = None, crosswalk_path: Path | None = None) -> dict:
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    sources = plan["sources"]
    crosswalk_path = crosswalk_path or Path(__file__).resolve().parents[2] / 'references/reference_crosswalk.csv'
    crosswalk = load_reference_mapping(crosswalk_path)
    sources = map_source_records(sources, crosswalk)
    ids = [s["reference_id"] for s in sources]
    if len(ids) != len(set(ids)):
        raise ValueError("The extraction plan contains duplicate reference identities.")
    if only and not only.issubset(set(ids)):
        raise ValueError("A requested --only reference is absent from the extraction plan.")
    text_dir.mkdir(parents=True, exist_ok=True)
    private_work = text_dir.parent / "ocr_work"
    private_work.mkdir(parents=True, exist_ok=True)
    log = []
    for source in sources:
        reference = source["reference_id"]
        if only and reference not in only:
            continue
        path = pdf_dir / source["filename"]
        actual_hash = sha256(path.read_bytes())
        if actual_hash != source["expected_file_sha256"]:
            raise ValueError(f"Source hash differs from the reviewed PDF: {reference} / {path.name}")
        method = source["extraction_method"]
        segments: list[dict] = []
        pdf = fitz.open(path)
        if source.get("regions"):
            for region in source["regions"]:
                number = int(region["page"])
                page = pdf[number - 1]
                if method == "tesseract_eng_verified":
                    for i, (text, bbox) in enumerate(ocr_region(page, region["rect"], private_work,
                                                              reference, number, region["region_id"]), 1):
                        add_segment(segments, text, number, f"{region['region_id']}_p{i}", method, bbox)
                else:
                    blocks = page.get_text("blocks", clip=fitz.Rect(region["rect"]), sort=True)
                    for i, block in enumerate(blocks, 1):
                        if len(block) > 6 and block[6] != 0:
                            continue
                        add_segment(segments, block[4], number, f"{region['region_id']}_b{i}", method,
                                    [round(x, 3) for x in block[:4]])
        else:
            for number in range(int(source["page_start"]), int(source["page_end"]) + 1):
                if number in source.get("excluded_pages", []):
                    continue
                if method == "pdftotext_layout":
                    result = subprocess.run(["pdftotext", "-f", str(number), "-l", str(number),
                                             "-layout", str(path), "-"], check=True,
                                            capture_output=True, text=True)
                    for i, block in enumerate(re.split(r"\n\s*\n", result.stdout.replace("\f", "\n")), 1):
                        add_segment(segments, block, number, f"layout_block{i}", method)
                else:
                    for i, block in enumerate(pdf[number - 1].get_text("blocks", sort=True), 1):
                        if len(block) > 6 and block[6] != 0:
                            continue
                        add_segment(segments, block[4], number, f"block{i}", method,
                                    [round(x, 3) for x in block[:4]])
        stop = source.get("text_end_before", "")
        if stop:
            retained = []
            stopped = False
            for segment in segments:
                if stop in segment["text"]:
                    prefix = segment["text"].split(stop, 1)[0].strip()
                    if prefix:
                        segment = dict(segment, text=prefix, text_sha256=sha256(prefix.encode("utf-8")))
                        retained.append(segment)
                    stopped = True
                    break
                retained.append(segment)
            if not stopped:
                raise ValueError(f"Required reviewed end marker absent for {reference}: {stop}")
            segments = retained
        if not segments:
            raise ValueError(f"Empty extraction for {reference}")
        text = "\n\n".join(s["text"] for s in segments) + "\n"
        text_hash = sha256(text.encode("utf-8"))
        (text_dir / f"{reference}.txt").write_text(text, encoding="utf-8")
        payload = {"reference_id": reference, "source_file_sha256": actual_hash,
                   "text_sha256": text_hash, "source_filename": path.name,
                   "language": source["language"], "document_scope": source["document_scope"],
                   "extraction_plan_sha256": sha256(plan_path.read_bytes()), "segments": segments}
        (text_dir / f"{reference}.pages.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        log.append({"reference_id": reference,
                    "source_register_number": source["source_register_number"],
                    "current_reference_number": source["final_reference_number"],
                    "final_reference_number": source["final_reference_number"],
                    "historical_pdf_id": source["historical_pdf_id"], "source_filename": path.name,
                    "source_file_sha256": actual_hash, "source_text_sha256": text_hash,
                    "local_text_path": f"private/source_texts/{reference}.txt",
                    "local_segments_path": f"private/source_texts/{reference}.pages.json",
                    "extraction_method": method, "language": source["language"],
                    "fulltext_status": "selected_complete_contribution" if source.get("regions") or
                    int(source["page_start"]) > 1 or int(source["page_end"]) < len(pdf) else "complete",
                    "include_english_retrieval": str(source["include_english_retrieval"]).lower(),
                    "document_scope": source["document_scope"], "segments": len(segments),
                    "whitespace_word_count": len(text.split()), "source_kind": source["source_kind"],
                    "review_note": source["review_note"]})
        print(f"Extracted {reference}: {len(text.split())} words, {len(segments)} segments", flush=True)
    updated = len(log)
    if only and log_path.is_file():
        with log_path.open(encoding="utf-8", newline="") as stream:
            retained = [row for row in csv.DictReader(stream) if row["reference_id"] not in only]
        log = sorted(retained + log, key=lambda row: row["reference_id"])
    write_csv(log_path, log)
    result = {"sources_extracted": len(log), "eligible_English_sources": sum(r["include_english_retrieval"] == "true" for r in log),
              "other_language_sources": [r["reference_id"] for r in log if r["include_english_retrieval"] != "true"],
              "plan_sha256": sha256(plan_path.read_bytes()), "text_is_private": True,
              "reference_crosswalk_sha256": sha256(crosswalk_path.read_bytes()),
              "duplicate_policy": "Historical PDF89 is an additional copy of R052, not a second source.",
              "source_fact_validation": "Extraction checks do not validate assertions in a source."}
    result["sources_updated_this_run"] = updated
    log_path.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--pdf-dir", type=Path, required=True)
    parser.add_argument("--private-text-dir", type=Path, required=True)
    parser.add_argument("--log-csv", type=Path, required=True)
    parser.add_argument("--only", nargs="+", help="Re-extract selected R### identities and update their log rows.")
    parser.add_argument("--reference-crosswalk", type=Path, default=None,
                        help="Defaults to the package references/reference_crosswalk.csv")
    args = parser.parse_args()
    try:
        print(json.dumps(extract(args.plan, args.pdf_dir, args.private_text_dir, args.log_csv,
                                 set(args.only) if args.only else None, args.reference_crosswalk), indent=2))
    except (ValueError, OSError, subprocess.CalledProcessError) as exc:
        print(f"EXTRACTION ERROR: {exc}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
