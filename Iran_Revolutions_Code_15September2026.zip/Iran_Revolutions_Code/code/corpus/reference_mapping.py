"""Map stable source identities to the final bibliography without adding texts."""
from pathlib import Path
import pandas as pd


def load_reference_mapping(path: Path) -> pd.DataFrame:
    frame = pd.read_csv(path, keep_default_na=False)
    required = {'reference_id', 'final_reference_number', 'source_register_number'}
    if not required.issubset(frame.columns):
        raise ValueError(f'Reference crosswalk lacks columns: {sorted(required-set(frame.columns))}')
    if frame.reference_id.duplicated().any() or frame.final_reference_number.duplicated().any():
        raise ValueError('Reference crosswalk contains duplicate identities or bibliography numbers')
    frame['final_reference_number'] = pd.to_numeric(frame.final_reference_number, errors='raise').astype(int)
    return frame


def map_source_frame(frame: pd.DataFrame, crosswalk: pd.DataFrame) -> pd.DataFrame:
    """Keep exactly the input source rows; ancillary notices are never appended."""
    lookup = crosswalk.set_index('reference_id')
    missing = set(frame.reference_id)-set(lookup.index)
    if missing:
        raise ValueError(f'Source identities absent from final crosswalk: {sorted(missing)}')
    selected = lookup.loc[frame.reference_id]
    if 'is_correction_notice' in selected:
        is_notice = selected.is_correction_notice.astype(str).str.lower().isin(['true','1','yes'])
        if is_notice.any():
            raise ValueError('Ancillary correction notice cannot be added as a corpus source')
    out = frame.copy()
    # The original register sequence remains explicit; current is a compatibility
    # alias for the final paper's numbered citation, never a source identifier.
    out['source_register_number'] = pd.to_numeric(selected.source_register_number, errors='raise').to_numpy(dtype=int)
    out['final_reference_number'] = selected.final_reference_number.to_numpy(dtype=int)
    out['current_reference_number'] = out.final_reference_number
    for column in ['title', 'full_citation']:
        if column in lookup and column in out:
            out[column] = selected[column].to_numpy()
    return out


def map_source_records(records: list[dict], crosswalk: pd.DataFrame) -> list[dict]:
    """Preserve heterogeneous recipe fields; do not introduce pandas NaNs."""
    identity = pd.DataFrame([{'reference_id': r['reference_id']} for r in records])
    mapped = map_source_frame(identity, crosswalk).to_dict('records')
    return [{**record, **numbers} for record, numbers in zip(records, mapped)]
