#!/usr/bin/env python3
"""Recover registered additional sources without redistributing source full text.

The default mode reads user-supplied raw files and verifies their SHA-256 hashes.
Use --download only for public URLs in the manifest. A changed substantive text is rejected
unless --allow-source-change is explicitly set; volatile HTML wrappers may change
when the extracted complete article text still matches its registered hash; such output needs new source review
and is not the registered analytical snapshot. This script never edits the frozen
source register, model inputs, bibliography, or manuscript.

Requirements: Python3.10+, PyMuPDF, lxml. DOCX extraction uses the standard library.
See SOURCE_RECOVERY_README.txt for examples and the scope of each format.
"""
from __future__ import annotations
import argparse
import copy
import hashlib
import json
from pathlib import Path
import re
import sys
import urllib.request
import zipfile

import fitz
from lxml import etree, html
from reference_mapping import load_reference_mapping, map_source_records


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def normalize(text: str) -> str:
    # This is the normalization used by the registered snapshot.
    return re.sub(r"[ \t]+", " ", text).strip() + "\n"


def tidy(element):
    element = copy.deepcopy(element)
    for child in element.xpath(
        ".//script|.//style|.//nav|.//footer|.//figure|.//button|.//svg|.//aside"
    ):
        child.drop_tree()
    return element


def paragraph_blocks(element, direct=False):
    nodes = list(element) if direct else element.xpath(".//p|.//h2|.//h3|.//h4|.//li")
    if element.tag == "p":
        nodes = [element]
    blocks = []
    for node in nodes:
        if node.tag not in ["p", "h1", "h2", "h3", "h4", "li"] and not (
            direct and node.get("class") == "lead"
        ):
            continue
        if not direct and node.tag == "p" and node.xpath("ancestor::li"):
            continue
        text = " ".join(node.text_content().split())
        if text and text not in blocks:
            blocks.append(text)
    return blocks


def extract_html(raw: bytes, recipe: dict) -> str:
    root = html.fromstring(raw.decode("utf8"))
    for selector in recipe.get("remove_xpath", []):
        for element in root.xpath(selector):
            element.drop_tree()
    number = recipe["filter_profile"]
    elements = root.xpath(recipe["html_xpath"])
    if not elements:
        raise ValueError("Registered article selector found no element")
    blocks = []
    for element in elements:
        element = tidy(element)
        if number == 49:
            blocks.append(" ".join(element.text_content().split()))
        else:
            blocks.extend(paragraph_blocks(element, direct=number in [23, 29, 30, 46]))
    if number == 69:
        blocks = [x for x in blocks if not x.startswith(("From:", "Media Relations", "Page details")) and x != "Contacts"]
    if number == 39 and "ABOUT THE RECORDING ACADEMY" in blocks:
        blocks = blocks[:blocks.index("ABOUT THE RECORDING ACADEMY")]
    if number == 40:
        blocks = [x for x in blocks if not x.startswith(("To cite this section", "MLA style")) and "NobelPrize.org." not in x]
    if number == 47:
        tags = {"DOWNTOWN LA", "LOS ANGELES", "LOS ANGELES COUNTY", "PROTEST", "RALLY", "IRAN", "U.S. & WORLD", "PRESIDENT DONALD TRUMP"}
        blocks = [x for x in blocks if not x.startswith(("Related", "Copyright", "POLITICS")) and x not in tags]
    if number == 51:
        blocks = [x for x in blocks if not x.startswith(("Top Stories", "Posted", "Last Updated", "Rogers"))]
    if number == 22:
        blocks = [x for x in blocks if not x.startswith(("Read more", "comments", "Follow"))]
    if number == 179:
        blocks = [x for x in blocks if not x.startswith("Sources:")]
    blocks = list(dict.fromkeys(blocks))
    if number == 45:
        # Retain the entire named speaker contribution, not only its Iran paragraph.
        start = blocks.index("Deputy Chief Rob Johnson")
        end = blocks.index("Deputy Chief Lauren Pogue")
        blocks = blocks[start:end]
    return "\n\n".join(blocks)

def extract_html_blocks_v2(raw: bytes, recipe: dict) -> str:
    """Registered article boundaries; no inferred article or synthetic fallback."""
    data=raw.decode(recipe['html_encoding']) if recipe.get('html_encoding') else raw
    root=html.fromstring(data)
    elements=root.xpath(recipe['html_xpath'])
    if len(elements)!=1:raise ValueError('Registered article selector must identify exactly one element')
    element=copy.deepcopy(elements[0])
    selectors=recipe.get('remove_xpath',['.//script','.//style','.//figure','.//iframe','.//*[contains(@class,"wsw__embed")]'])
    for selector in selectors:
        for child in element.xpath(selector):child.drop_tree()
    blocks=[]
    for node in element.xpath('.//p|.//h1|.//h2|.//h3|.//h4|.//li'):
        if node.tag=='p' and node.xpath('ancestor::li'):continue
        text=' '.join(node.text_content().split())
        if text and text not in blocks:blocks.append(text)
    return '\n\n'.join(blocks)


def extract_pdf(path: Path, recipe: dict) -> str:
    with fitz.open(path) as document:
        pages = recipe.get("pdf_page_indices_zero_based")
        if pages is None:
            pages = list(range(len(document)))
        if not pages or min(pages) < 0 or max(pages) >= len(document):
            raise ValueError("Registered PDF page bounds do not match the supplied document")
        prefix = recipe.get("pdf_prefix_page_markers", True)
        if prefix:
            text = "\n\n".join(f"[PDF PAGE {i+1}]\n" + document[i].get_text() for i in pages)
        else:
            text = recipe.get('pdf_page_separator','\n\n').join(document[i].get_text() for i in pages)
    if recipe.get("start_at"):
        start = text.index(recipe["start_at"])
        end = text.index(recipe["end_before"], start)
        text = text[start:end]
    return text


def extract_docx(path: Path) -> str:
    namespace = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
    blocks = []
    with zipfile.ZipFile(path) as archive:
        root = etree.fromstring(archive.read("word/document.xml"))
        # Includes table-cell paragraphs in their original document order.
        for paragraph in root.xpath("//w:body//w:p", namespaces=namespace):
            text = "".join(paragraph.xpath(".//w:t/text()", namespaces=namespace))
            if text.strip():
                blocks.append(text)
        for part in ["footnotes", "endnotes"]:
            member = "word/" + part + ".xml"
            if member not in archive.namelist():
                continue
            root = etree.fromstring(archive.read(member))
            for note in root:
                text = " ".join(
                    "".join(p.xpath(".//w:t/text()", namespaces=namespace))
                    for p in note.xpath(".//w:p", namespaces=namespace)
                ).strip()
                if text:
                    note_id = note.get("{" + namespace["w"] + "}id")
                    blocks.append(f"[{part} id={note_id}] " + text)
    return "\n\n".join(blocks)


def extract_jats(raw: bytes) -> str:
    root = etree.fromstring(raw)
    nodes = root.xpath(
        "./front/article-meta/title-group/article-title | ./front//abstract//p | "
        "./body//title | ./body//p | ./body//table-wrap//tr | "
        "./back//title | ./back//p | ./back//ref"
    )
    blocks = []
    for element in nodes:
        if element.tag == "p" and element.xpath("ancestor::ref"):
            continue
        text = " ".join("".join(element.itertext()).split())
        if text:
            blocks.append(text)
    return "\n\n".join(blocks)


def recover(recipe: dict, raw_path: Path, output_dir: Path, download: bool, allow_change: bool) -> dict:
    report = {"reference_id": recipe["reference_id"],
              "source_register_number": recipe.get("source_register_number"),
              "current_reference_number": recipe.get("final_reference_number"),
              "final_reference_number": recipe.get("final_reference_number"),
              "url": recipe["url"], "raw_path": str(raw_path), "registered_scope": recipe["scope"]}
    if not raw_path.is_file():
        if not download:
            raise FileNotFoundError(f"Raw source not found: {raw_path}; supply the source or use --download")
        raw_path.parent.mkdir(parents=True, exist_ok=True)
        request = urllib.request.Request(recipe["url"], headers={"User-Agent": "Mozilla/5.0 (Source recovery for scholarly reproducibility)"})
        with urllib.request.urlopen(request, timeout=60) as response:
            raw = response.read()
            report["resolved_url"] = response.geturl()
            report["content_type"] = response.headers.get("Content-Type", "")
        raw_path.write_bytes(raw)
    else:
        raw = raw_path.read_bytes()
    binary_hash = sha256(raw)
    binary_match = binary_hash == recipe["expected_binary_sha256"]
    report.update(binary_sha256=binary_hash, binary_hash_matches=binary_match)
    if not binary_match and not allow_change and recipe["extraction_kind"] not in ["html_article","html_blocks_v2"]:
        raise ValueError(f"Binary hash differs for {recipe['reference_id']}; changed versions need a new identity/scope review")
    kind = recipe["extraction_kind"]
    if kind == "html_article":
        text = extract_html(raw, recipe)
    elif kind == 'html_blocks_v2':
        text = extract_html_blocks_v2(raw,recipe)
    elif kind == "pdf":
        text = extract_pdf(raw_path, recipe)
    elif kind == "docx":
        text = extract_docx(raw_path)
    elif kind == "xml_jats":
        text = extract_jats(raw)
    else:
        raise ValueError(f"Unsupported extraction kind: {kind}")
    if recipe.get('post_extract_end_before'):
        marker=recipe['post_extract_end_before']
        if marker not in text:raise ValueError('Registered ending marker not found')
        text=text[:text.index(marker)]
    for old,new in recipe.get('literal_replacements',[]):
        if old not in text:raise ValueError('Registered literal replacement not found')
        text=text.replace(old,new)
    for value in recipe.get('remove_unicode_codepoints',[]):text=text.replace(chr(int(value,16)),'')
    profile=recipe.get('normalization_profile','registered_spaces_tabs')
    if profile=='registered_spaces_tabs':text=normalize(text)
    elif profile!='preserve_extracted_text':raise ValueError('Unknown normalization profile')
    text_hash = sha256(text.encode("utf-8"))
    text_match = text_hash == recipe["expected_text_sha256"]
    report.update(text_sha256=text_hash, text_hash_matches=text_match, whitespace_words=len(text.split()))
    if not text_match and not allow_change:
        raise ValueError(f"Extracted text differs for {recipe['reference_id']}; check dependency versions and extraction order before analysis")
    output_dir.mkdir(parents=True, exist_ok=True)
    target = output_dir / (recipe["reference_id"] + ".txt")
    if target.exists() and target.read_bytes() != text.encode("utf-8"):
        raise FileExistsError(f"Refusing to replace different existing text: {target}. Use a new output directory.")
    target.write_text(text, encoding="utf-8")
    report.update(output_path=str(target), registered_snapshot_reproduced=text_match and (binary_match or kind in ["html_article","html_blocks_v2"]), fulltext_status=recipe["fulltext_status"], eligible_in_registered_analysis=recipe["include_text_analysis"] and text_match and (binary_match or kind in ["html_article","html_blocks_v2"]))
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--recipes", type=Path, default=Path(__file__).parent / "inputs/additional_source_recipes.json")
    parser.add_argument("--raw-dir", type=Path, help="Directory with the public-source raw filenames recorded in the recipes")
    parser.add_argument("--use-recorded-cache", type=Path, help="Private project root containing the recorded relative cache paths")
    parser.add_argument("--output-dir", required=True, type=Path, help="Private output directory; do not commit full texts to GitHub")
    parser.add_argument("--ids", help="Comma-separated stable reference IDs; default is all registered additional sources")
    parser.add_argument("--reference-crosswalk", type=Path, default=None,
                        help="Defaults to the package references/reference_crosswalk.csv")
    parser.add_argument("--download", action="store_true", help="Download absent raw files from the registered public URL; hashes are still checked")
    parser.add_argument("--allow-source-change", action="store_true", help="Extract a changed version for NEW review only; it cannot reproduce this snapshot")
    args = parser.parse_args()
    if bool(args.raw_dir) == bool(args.use_recorded_cache):
        parser.error("Choose exactly one of --raw-dir or --use-recorded-cache")
    manifest = json.loads(args.recipes.read_text(encoding="utf-8"))
    crosswalk_path = args.reference_crosswalk or Path(__file__).resolve().parents[2] / 'references/reference_crosswalk.csv'
    crosswalk = load_reference_mapping(crosswalk_path)
    # Update metadata only; no ancillary references are added to the source recipes.
    manifest['sources'] = map_source_records(manifest['sources'], crosswalk)
    ids = {x.strip() for x in args.ids.split(",")} if args.ids else None
    sources = [x for x in manifest["sources"] if ids is None or x["reference_id"] in ids]
    if ids and ids != {x["reference_id"] for x in sources}:
        parser.error("Unknown IDs: " + ", ".join(sorted(ids - {x['reference_id'] for x in sources})))
    results = []
    for recipe in sources:
        raw_path = args.use_recorded_cache / recipe["recorded_binary_path"] if args.use_recorded_cache else args.raw_dir / recipe["raw_file"]
        try:
            report = recover(recipe, raw_path, args.output_dir, args.download, args.allow_source_change)
            report["status"] = "ok"
            print(recipe["reference_id"], "verified" if report["registered_snapshot_reproduced"] else "CHANGED VERSION: review required")
        except Exception as error:
            report = {"reference_id": recipe["reference_id"], "status": "failed", "error": str(error)}
            print(recipe["reference_id"], str(error), file=sys.stderr)
        results.append(report)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    log = {"recipe_manifest_sha256": sha256(args.recipes.read_bytes()),
           "registered_source_register_sha256": manifest["source_register_sha256"],
           "reference_crosswalk_sha256": sha256(crosswalk_path.read_bytes()), "results": results}
    (args.output_dir / "source_recovery_log.json").write_text(json.dumps(log, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return 1 if any(x["status"] != "ok" for x in results) else 0


if __name__ == "__main__":
    raise SystemExit(main())
