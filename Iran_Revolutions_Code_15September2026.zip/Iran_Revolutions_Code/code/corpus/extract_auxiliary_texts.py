#!/usr/bin/env python3
"""Reproduce explicitly bounded auxiliary abstracts without treating them as full texts."""
import argparse
import hashlib
import json
from pathlib import Path
import fitz


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--pdf-dir", type=Path, required=True)
    parser.add_argument("--private-text-dir", type=Path, required=True)
    args = parser.parse_args()
    args.private_text_dir.mkdir(parents=True, exist_ok=True)
    for record in json.loads(args.plan.read_text())["auxiliary_texts"]:
        pdf = fitz.open(args.pdf_dir / record["filename"])
        text = pdf[record["page"] - 1].get_text(clip=fitz.Rect(record["rectangle_pdf_points"])).strip() + "\n"
        if hashlib.sha256(text.encode()).hexdigest() != record["sha256"]:
            raise ValueError(f"Auxiliary extraction hash changed: {record['reference_id']}")
        (args.private_text_dir / record["output_filename"]).write_text(text, encoding="utf-8")
        print(record["reference_id"], record["available_text_scope"])


if __name__ == "__main__":
    main()
