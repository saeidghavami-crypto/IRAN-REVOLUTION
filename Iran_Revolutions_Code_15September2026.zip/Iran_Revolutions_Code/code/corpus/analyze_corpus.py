#!/usr/bin/env python3
"""Reproducible source-level text mapping, not a model of revolutionary success.

Run from the study root. Copyrighted source text is read only from a private
directory and is never written to the public output directory. Each registered
source identity contributes once. Input hashes are verified before analysis.
"""
from __future__ import annotations
import argparse
import calendar
from datetime import date
import hashlib
import itertools
import json
import re
import sys
import unicodedata
from pathlib import Path

import numpy as np
import pandas as pd
import scipy
from scipy.stats import spearmanr
import sklearn
from sklearn.cluster import KMeans
from sklearn.decomposition import TruncatedSVD
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics import adjusted_rand_score, normalized_mutual_info_score, silhouette_score
from sklearn.metrics.pairwise import cosine_similarity
from threadpoolctl import threadpool_limits
from reference_mapping import load_reference_mapping, map_source_frame

SEEDS = [0, 1, 2, 3, 42]
ANCHOR_SEED = 42
K_RANGE = list(range(2, 11))

def digest(b):
    return hashlib.sha256(b).hexdigest()

def normalize(text):
    """Preserve Unicode letters; repair line wraps without speculative stemming."""
    text = unicodedata.normalize('NFKC', text).replace('\u00ad','').replace('￾','')
    text = text.replace('’', "'").replace('‘', "'").replace('–','-').replace('—','-')
    text = re.sub(r'(?<=\w)-\s*\n\s*(?=\w)', '', text)
    text = re.sub(r'https?://\S+|\b\S+@\S+\b', ' ', text)
    text = re.sub(r'\[PDF PAGE \d+\]', ' ', text)
    return re.sub(r'\s+', ' ', text).strip().casefold()

def truth(x):
    return str(x).strip().lower() in {'true','1','yes'}

def publication_interval(value):
    """Use only documented date precision; do not impute a missing day."""
    value=str(value).strip()
    if re.fullmatch(r'\d{4}-\d{2}-\d{2}',value):
        day=date.fromisoformat(value)
        return day,day,'day'
    if re.fullmatch(r'\d{4}-\d{2}',value):
        year,month=map(int,value.split('-'))
        return date(year,month,1),date(year,month,calendar.monthrange(year,month)[1]),'month'
    if re.fullmatch(r'\d{4}',value):
        year=int(value)
        return date(year,1,1),date(year,12,31),'year'
    return None,None,'unknown'

def publication_status(row,cutoff):
    first=str(row.get('first_public_date','')).strip()
    value=first or str(row.get('source_publication_date','')).strip() or str(row.get('publication_time','')).strip()
    basis='documented_first_public_date' if first else 'registered_publication_date'
    low,high,precision=publication_interval(value)
    if str(row.get('publication_availability_status','')).strip()=='pre_cutoff_availability_unverified':
        status='unverified_public_availability'
        basis='cover_date_with_unverified_first_public_availability'
    elif high is None:status='unknown_date'
    elif high<=cutoff:status='by_cutoff'
    elif low>cutoff:status='after_cutoff'
    else:status='date_interval_crosses_cutoff'
    return {'publication_date_used':value,'publication_date_basis':basis,
            'publication_date_precision':precision,'publication_timing':status}

def genre_group(v):
    s=v.lower().replace('_',' ')
    if any(t in s for t in ['thesis','dissertation','student','bachelor','first-year','undergraduate']):
        return 'Student work or thesis'
    if any(t in s for t in ['news','podcast','encyclopedia']):
        return 'Journalism or reference work'
    if any(t in s for t in ['actor','charter']):
        return 'Political actor document'
    if any(t in s for t in ['human rights','institutional','government','police','fact finding','report','transcript','dossier']):
        return 'Institutional or policy document'
    if any(t in s for t in ['journal','article','chapter','book','conference','essay','commentary','preprint','editorial','contribution']):
        return 'Scholarly publication or commentary'
    return 'Other documented genre'

def vectorize(docs, dimensions=35, ngram=(1,2), max_features=7000, min_df=2,
              max_df=.95, extra_stop_words=None):
    stop='english'
    if extra_stop_words:
        from sklearn.feature_extraction.text import ENGLISH_STOP_WORDS
        stop=sorted(set(ENGLISH_STOP_WORDS)|set(extra_stop_words))
    v=TfidfVectorizer(ngram_range=ngram, max_features=max_features, min_df=min_df,
       max_df=max_df, sublinear_tf=True, norm='l2', stop_words=stop,
       strip_accents=None, token_pattern=r'(?u)\b[^\W\d_][^\W_]+\b')
    x=v.fit_transform(docs)
    dim=min(dimensions,x.shape[0]-2,x.shape[1]-1)
    s=TruncatedSVD(n_components=dim, n_iter=10, random_state=ANCHOR_SEED)
    z=s.fit_transform(x)
    return v,x,s,z

def fit_clusters(z,seeds=SEEDS):
    rows=[];models={}
    for k in K_RANGE:
        if k>=len(z):continue
        for seed in seeds:
            m=KMeans(n_clusters=k,n_init=50,random_state=seed,algorithm='lloyd')
            y=m.fit_predict(z)
            counts=np.bincount(y)
            rows.append({'k':k,'seed':seed,'silhouette':float(silhouette_score(z,y)),
                         'inertia':float(m.inertia_),'minimum_cluster_size':int(counts.min())})
            models[k,seed]=(m,y)
    run=pd.DataFrame(rows)
    summary=run.groupby('k',as_index=False).agg(mean_silhouette=('silhouette','mean'),
        minimum_silhouette=('silhouette','min'),maximum_silhouette=('silhouette','max'),
        mean_inertia=('inertia','mean'),minimum_cluster_size=('minimum_cluster_size','min'))
    # Ascending k breaks exact score ties in favor of the simpler partition.
    selected=int(summary.sort_values(['mean_silhouette','k'],ascending=[False,True]).iloc[0].k)
    summary['selected']=summary.k.eq(selected)
    pair=[]
    for a,b in itertools.combinations(seeds,2):
        pair.append({'seed_a':a,'seed_b':b,'k':selected,
            'adjusted_rand_index':float(adjusted_rand_score(models[selected,a][1],models[selected,b][1]))})
    return selected,models,run,summary,pd.DataFrame(pair)

def presence_summary(counts,lexicon,weights=None):
    rows=[]
    w=np.ones(len(counts)) if weights is None else np.asarray(weights,dtype=float)
    for x in lexicon:
        c=x['category_id'];p=counts[c].gt(0).to_numpy()
        rows.append({'category_id':c,'category_label':x['display_label'],
          'n_sources':len(counts),'sources_with_mentions':int(p.sum()),
          'presence_pct':float(p.mean()*100),
          'weighted_presence_pct':float(np.average(p,weights=w)*100)})
    return pd.DataFrame(rows)

def save(df,out,name):
    df.to_csv(out/name,index=False,float_format='%.10g')

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--source-register',type=Path,default=Path('code/corpus/inputs/source_register.csv'))
    ap.add_argument('--lexicon',type=Path,default=Path('code/corpus/inputs/dictionaries.json'))
    ap.add_argument('--reference-crosswalk',type=Path,default=None,
                    help='Defaults to references/reference_crosswalk.csv under --study-root')
    ap.add_argument('--study-root',type=Path,default=Path('.'))
    ap.add_argument('--out',type=Path,default=Path('outputs/corpus'))
    ap.add_argument('--publication-cutoff',default='2026-09-15',help='Inclusive source-publication sensitivity cutoff; not a substitute for event coverage')
    args=ap.parse_args();args.out.mkdir(parents=True,exist_ok=True)
    cutoff=date.fromisoformat(args.publication_cutoff)
    reg=pd.read_csv(args.source_register,keep_default_na=False)
    if reg.reference_id.duplicated().any():raise ValueError('Duplicate registered source identity')
    crosswalk_path=args.reference_crosswalk or args.study_root/'references/reference_crosswalk.csv'
    crosswalk=load_reference_mapping(crosswalk_path)
    reg=map_source_frame(reg,crosswalk)
    lexicon=json.loads(args.lexicon.read_text())['categories']
    if len(lexicon)!=14:raise ValueError('Expected 14 transparent dictionaries')
    docs=[];eligible=[];allrows=[]
    for row in reg.to_dict('records'):
        use=truth(row['include_text_analysis'])
        path=args.study_root/row['local_text_path'] if row['local_text_path'] else None
        audit={**row,**publication_status(row,cutoff),'eligible_text_analysis':use,'genre_group':genre_group(row['publication_type']),
               'raw_words':0,'normalized_words':0,'normalized_text_sha256':''}
        if use:
            if str(row['language'])!='en':raise ValueError('Non-English source marked eligible')
            if row['fulltext_status'] not in ['complete','selected_complete_contribution']:
                raise ValueError('Incomplete source marked eligible')
            if path is None or not path.is_file():raise FileNotFoundError(f'No complete text for {row["reference_id"]}')
            raw=path.read_bytes()
            if digest(raw)!=row['source_text_sha256']:
                raise ValueError(f'Text hash mismatch: {row["reference_id"]}')
            text=raw.decode('utf-8');clean=normalize(text)
            audit.update(raw_words=len(text.split()),normalized_words=len(clean.split()),
                         normalized_text_sha256=digest(clean.encode()))
            if not clean:raise ValueError('Empty eligible source')
            eligible.append(audit);docs.append(clean)
        allrows.append(audit)
    meta=pd.DataFrame(eligible)
    if meta.normalized_text_sha256.duplicated().any():
        raise ValueError('Exact normalized-text duplicate requires identity review; no automatic reweighting')
    public_manifest=pd.DataFrame(allrows).drop(columns=['local_binary_path','retrieval_metadata_path','auxiliary_abstract_path'],errors='ignore')
    save(public_manifest,args.out,'source_manifest.csv')
    coverage=[]
    for col in ['language','fulltext_status','source_role','event_coverage','genre_group','publication_timing']:
        for val,g in public_manifest.groupby(col):
            e=g[g.eligible_text_analysis]
            coverage.append({'dimension':col,'stratum':val,'registered_sources':len(g),
                'eligible_sources':len(e),'normalized_words':int(e.normalized_words.sum()),
                'median_words':float(e.normalized_words.median()) if len(e) else 0})
    save(pd.DataFrame(coverage),args.out,'source_coverage.csv')
    accounting=pd.DataFrame(coverage)[['dimension','stratum','registered_sources','eligible_sources']].rename(
        columns={'stratum':'category','registered_sources':'registered','eligible_sources':'included_in_text_mapping'})
    save(accounting,args.out,'supplementary_source_accounting.csv')
    # Equal source contributions; frequency is an auxiliary descriptive measure.
    score=[];term_rows=[]
    for row,txt in zip(eligible,docs):
        sr={'reference_id':row['reference_id'],
            'source_register_number':row['source_register_number'],
            'current_reference_number':row['final_reference_number'],
            'final_reference_number':row['final_reference_number'],
            'source_role':row['source_role'],
            'event_coverage':row['event_coverage'],'genre_group':row['genre_group'],
            'publication_timing':row['publication_timing'],
            'words':row['normalized_words']}
        for dic in lexicon:
            hits=0
            for term in dic['terms']:
                n=len(re.findall(r'(?<!\w)'+re.escape(term.casefold())+r'(?!\w)',txt))
                hits+=n
                if n:term_rows.append({'reference_id':row['reference_id'],
                    'source_register_number':row['source_register_number'],
                    'current_reference_number':row['final_reference_number'],
                    'final_reference_number':row['final_reference_number'],
                    'category_id':dic['category_id'],'term':term,'count':n})
            sr[dic['category_id']]=hits
            sr[dic['category_id']+'_per_10k']=10000*hits/row['normalized_words']
        score.append(sr)
    scores=pd.DataFrame(score);save(scores,args.out,'dictionary_source_counts.csv')
    save(pd.DataFrame(term_rows),args.out,'dictionary_term_counts.csv')
    dsum=presence_summary(scores,lexicon)
    dsum['mean_mentions_per_10k']=[float(scores[x['category_id']+'_per_10k'].mean()) for x in lexicon]
    dsum['median_mentions_per_10k']=[float(scores[x['category_id']+'_per_10k'].median()) for x in lexicon]
    save(dsum,args.out,'dictionary_summary.csv')
    strata=[]
    for col in ['source_role','event_coverage','genre_group','publication_timing']:
        for val,g in scores.groupby(col):
            sub=presence_summary(g,lexicon);sub.insert(0,'stratum',val);sub.insert(0,'dimension',col)
            strata.extend(sub.to_dict('records'))
    save(pd.DataFrame(strata),args.out,'dictionary_strata.csv')
    y=scores[[q['category_id'] for q in lexicon]].gt(0).to_numpy()
    co=[]
    for i,a in enumerate(lexicon):
        for j,b in enumerate(lexicon):
            intersection=int(np.logical_and(y[:,i],y[:,j]).sum())
            union=int(np.logical_or(y[:,i],y[:,j]).sum())
            co.append({'category_a':a['category_id'],'category_b':b['category_id'],
                'n_both':intersection,'n_either':union,'jaccard':intersection/union if union else np.nan})
    save(pd.DataFrame(co),args.out,'dictionary_cooccurrence.csv')
    masks={
      'all_eligible_sources':np.ones(len(meta),dtype=bool),
      'exclude_contextual_background':meta.source_role.ne('contextual_background').to_numpy(),
      'Iran_cases_only':meta.event_coverage.isin(['WLF','LionSun_2025_2026']).to_numpy(),
      'exclude_actor_statements':meta.source_role.ne('actor_statement').to_numpy(),
      'scholarly_analysis_only':meta.source_role.eq('scholarly_analysis').to_numpy(),
      'whole_sources_only':meta.fulltext_status.eq('complete').to_numpy(),
      'published_by_cutoff_known_interval':meta.publication_timing.eq('by_cutoff').to_numpy()}
    ds=[]
    for name,mask in masks.items():
        temp=presence_summary(scores.loc[mask],lexicon);temp.insert(0,'analysis',name)
        ds.extend(temp.to_dict('records'))
    # Equalizes case groups, not the number of independent historical campaigns.
    cm=masks['Iran_cases_only'];cw=1/meta.loc[cm,'event_coverage'].map(meta.loc[cm,'event_coverage'].value_counts()).to_numpy()
    temp=presence_summary(scores.loc[cm],lexicon,cw);temp.insert(0,'analysis','equal_weight_WLF_and_LionSun_source_groups');ds.extend(temp.to_dict('records'))
    gw=1/meta.dependency_group.map(meta.dependency_group.value_counts()).to_numpy()
    temp=presence_summary(scores,lexicon,gw);temp.insert(0,'analysis','equal_provenance_family_weight');ds.extend(temp.to_dict('records'))
    gg=1/meta.genre_group.map(meta.genre_group.value_counts()).to_numpy()
    temp=presence_summary(scores,lexicon,gg);temp.insert(0,'analysis','equal_genre_group_weight');ds.extend(temp.to_dict('records'))
    ds=pd.DataFrame(ds)
    baseline=dict(zip(dsum.category_id,dsum.presence_pct))
    ds['difference_percentage_points']=ds.weighted_presence_pct-ds.category_id.map(baseline)
    save(ds,args.out,'dictionary_sensitivity.csv')
    with threadpool_limits(limits=1):
        vec,x,svd,z=vectorize(docs)
        k,models,runs,selection,stability=fit_clusters(z)
        km,lab=models[k,ANCHOR_SEED]
        # Neutral reproducible IDs follow lowest registered source ID in a cluster.
        old_order=sorted(set(lab),key=lambda j:min(meta.loc[lab==j,'reference_id']))
        remap={v:i+1 for i,v in enumerate(old_order)}
        lab_public=np.array([remap[i] for i in lab])
        assign=meta[['reference_id','source_register_number','current_reference_number','final_reference_number',
                     'title','source_role','event_coverage','genre_group','normalized_words']].copy()
        assign['cluster']=lab_public
        for i in range(z.shape[1]):assign[f'svd_{i+1:02d}']=z[:,i]
        save(assign,args.out,'source_cluster_coordinates.csv')
        save(runs,args.out,'cluster_selection_runs.csv');save(selection,args.out,'cluster_selection.csv');save(stability,args.out,'cluster_seed_stability.csv')
        terms=np.array(vec.get_feature_names_out());centers=km.cluster_centers_@svd.components_
        clusters=[]
        for old in old_order:
            clusters.append({'cluster':remap[old],'n_sources':int((lab==old).sum()),
                'top_terms':' | '.join(terms[np.argsort(centers[old])[-15:][::-1]])})
        save(pd.DataFrame(clusters),args.out,'cluster_terms.csv')
        assoc=[];comp=[]
        for col in ['source_role','event_coverage','genre_group']:
            assoc.append({'metadata_dimension':col,
                'normalized_mutual_information':float(normalized_mutual_info_score(meta[col],lab)),
                'adjusted_rand_index':float(adjusted_rand_score(meta[col],lab))})
            for (c,s),g in assign.groupby(['cluster',col]):comp.append({'cluster':c,'metadata_dimension':col,'stratum':s,'n':len(g)})
        save(pd.DataFrame(assoc),args.out,'cluster_metadata_association.csv');save(pd.DataFrame(comp),args.out,'cluster_composition.csv')
        sim=cosine_similarity(x);near=[]
        for i,j in zip(*np.where(np.triu(sim,k=1)>=.8)):
            near.append({'reference_a':meta.iloc[i].reference_id,'reference_b':meta.iloc[j].reference_id,
                'tfidf_cosine_similarity':float(sim[i,j]),'action':'Retained distinct source identities; inspect provenance and selected scopes.'})
        save(pd.DataFrame(near,columns=['reference_a','reference_b','tfidf_cosine_similarity','action']),args.out,'high_similarity_pairs.csv')
        sensitivity=[]
        scenarios=[('exclude_contextual_background',masks['exclude_contextual_background'],{}),
            ('Iran_cases_only',masks['Iran_cases_only'],{}),
            ('published_by_cutoff_known_interval',masks['published_by_cutoff_known_interval'],{}),
            ('SVD_16_dimensions',masks['all_eligible_sources'],{'dimensions':16}),
            ('SVD_64_dimensions',masks['all_eligible_sources'],{'dimensions':64}),
            ('unigrams_only',masks['all_eligible_sources'],{'ngram':(1,1)})]
        for name,mask,kw in scenarios:
            vv,xx,ss,zz=vectorize([t for t,m in zip(docs,mask) if m],**kw)
            kk,mm,rr,select,_=fit_clusters(zz,seeds=[ANCHOR_SEED])
            ll=mm[kk,ANCHOR_SEED][1]
            sensitivity.append({'analysis':name,'n_sources':int(mask.sum()),'n_tfidf_features':xx.shape[1],
               'svd_dimensions':zz.shape[1],'selected_k':kk,
               'silhouette':float(select.loc[select.selected,'mean_silhouette'].iloc[0]),
               'adjusted_rand_to_primary_shared_sources':float(adjusted_rand_score(lab[mask],ll)),
               'selection_seeds':'42','selection_rule':'maximum silhouette over k=2..10 at seed42'})
        save(pd.DataFrame(sensitivity),args.out,'clustering_sensitivity.csv')
    full=reg.fulltext_status.isin(['complete','selected_complete_contribution'])
    notice_count=int(crosswalk.get('is_correction_notice',pd.Series(False,index=crosswalk.index)).astype(str).str.lower().isin(['true','1','yes']).sum())
    summary={'registered_sources':len(reg),'bibliography_entries':len(crosswalk),
      'ancillary_correction_notices':notice_count,
      'complete_or_selected_complete_sources':int(full.sum()),
      'eligible_English_sources':len(meta),'excluded_from_text_mapping':len(reg)-len(meta),
      'exclusion_status_counts':reg.loc[~reg.include_text_analysis.map(truth),'fulltext_status'].value_counts().to_dict(),
      'eligible_source_roles':meta.source_role.value_counts().to_dict(),
      'eligible_case_coverage':meta.event_coverage.value_counts().to_dict(),
      'eligible_scope_counts':meta.fulltext_status.value_counts().to_dict(),
      'publication_cutoff':args.publication_cutoff,
      'eligible_publication_timing_counts':meta.publication_timing.value_counts().to_dict(),
      'publication_sensitivity_rule':'Include only sources whose documented first public date, or full registered publication-date interval, ends on or before the cutoff, with no unresolved first-availability qualification. Later, unknown, cutoff-spanning or explicitly unverified first-availability dates remain in the primary corpus but are excluded from this sensitivity.',
      'eligible_raw_words':int(meta.raw_words.sum()),'eligible_normalized_words':int(meta.normalized_words.sum()),
      'median_normalized_words':float(meta.normalized_words.median()),
      'tfidf_features':int(x.shape[1]),'svd_dimensions':int(z.shape[1]),
      'svd_total_explained_variance_ratio':float(svd.explained_variance_ratio_.sum()),
      'svd_first3_explained_variance_ratio':float(svd.explained_variance_ratio_[:3].sum()),
      'selected_k':k,'selected_mean_silhouette':float(selection.loc[selection.selected,'mean_silhouette'].iloc[0]),
      'anchor_seed_silhouette':float(runs.loc[(runs.k==k)&(runs.seed==42),'silhouette'].iloc[0]),
      'cluster_sizes':pd.Series(lab_public).value_counts().sort_index().to_dict(),
      'median_pairwise_seed_adjusted_rand':float(stability.adjusted_rand_index.median()),
      'minimum_pairwise_seed_adjusted_rand':float(stability.adjusted_rand_index.min()),
      'maximum_pairwise_seed_adjusted_rand':float(stability.adjusted_rand_index.max()),
      'selection_seeds':SEEDS,'k_range':K_RANGE,'kmeans_n_init':50,
      'source_register_sha256':digest(args.source_register.read_bytes()),'lexicon_sha256':digest(args.lexicon.read_bytes()),
      'reference_crosswalk_sha256':digest(crosswalk_path.read_bytes()),
      'software':{'python':sys.version.split()[0],'numpy':np.__version__,'pandas':pd.__version__,
                  'scipy':scipy.__version__,'scikit_learn':sklearn.__version__},
      'interpretation':'Source-level descriptive mapping. Documents are not independent revolutions; clusters and mention rates do not identify causes, mechanism strength, or probability of transition.',
      'public_outputs_contain_source_full_text':False}
    (args.out/'corpus_run_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
    validation={
      'registered_source_count':len(reg),'eligible_text_count':len(meta),'bibliography_entry_count':len(crosswalk),
      'checks':{
        'source_register_unique':bool(reg.reference_id.is_unique),
        'source_manifest_accounts_for_all_registered_sources':len(public_manifest)==len(reg),
        'eligible_manifest_matches_analysis_rows':int(public_manifest.eligible_text_analysis.sum())==len(meta),
        'all_eligible_text_hashes_verified_before_analysis':True,
        'normalized_text_hashes_unique':bool(meta.normalized_text_sha256.is_unique),
        'cluster_sizes_sum_to_eligible_count':int(pd.Series(lab_public).value_counts().sum())==len(meta),
        'all_svd_coordinates_finite':bool(np.isfinite(z).all()),
        'dictionary_category_count_is_14':len(dsum)==14,
        'dictionary_presence_within_source_denominator':bool(dsum.sources_with_mentions.between(0,len(meta)).all()),
        'correction_notices_excluded_from_source_register':not any(reg.reference_id.isin(crosswalk.loc[crosswalk.is_correction_notice.astype(str).str.lower().isin(['true','1','yes']),'reference_id'])),
        'cutoff_sensitivity_has_documented_eligible_date_interval':bool(meta.loc[masks['published_by_cutoff_known_interval'],'publication_timing'].eq('by_cutoff').all())},
      'source_register_sha256':summary['source_register_sha256'],
      'reference_crosswalk_sha256':summary['reference_crosswalk_sha256'],
      'scope':'Validation of source identities, private input hashes and derived numerical output cardinalities for the current full analysis.'}
    if not all(validation['checks'].values()):raise AssertionError('Corpus validation failed')
    (args.out/'validation_checks.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2)+'\n')
    mapping_validation={
      'scope':'Stable source identifiers joined to the current reference crosswalk; no citation number is used as a text-model feature.',
      'registered_sources':len(reg),'bibliography_entries':len(crosswalk),
      'source_register_sha256':summary['source_register_sha256'],
      'reference_crosswalk_sha256':summary['reference_crosswalk_sha256'],
      'source_ids_unique':bool(reg.reference_id.is_unique),
      'source_ids_present_in_crosswalk':bool(reg.reference_id.isin(crosswalk.reference_id).all()),
      'correction_notices_outside_source_register':validation['checks']['correction_notices_excluded_from_source_register']}
    (args.out/'metadata_mapping_validation.json').write_text(json.dumps(mapping_validation,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(summary,indent=2))
    print(dsum[['category_label','sources_with_mentions','presence_pct']].to_string(index=False))

if __name__=='__main__':main()
